# Beats (brand)

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/Beats_(brand)>*

Beats Electronics (also known as Beats by Dre, Beats by Dr. Dre or simply Beats) is an American consumer audio products and accessories manufacturer headquartered in Culver City, California. The company was founded in 2006 by the music producer Dr. Dre and the co-founder of Interscope Records and former CEO of Interscope Geffen A&M, Jimmy Iovine. Beats was acquired by Apple Inc. in 2014, where they have used Beats to release other products centered around Apple's ecosystem, but are released under the name of Beats.
Beats' product line is primarily focused on headphones, speakers, and accessories. The company's original product line was manufactured in partnership with the AV equipment company Monster Cable Products. Following the end of its contract with the company, Beats took further development of its products in-house. In 2014, the company expanded into the online music market with the launch of a subscription-based streaming service, Beats Music.
In 2011, NPD Group reported that Beats' market share was 64% in the U.S. for headphones priced higher than $100, and the brand was valued at $1 billion in September 2013.
For a period, the company was majority-owned by the Taiwanese electronics company HTC. The company reduced its stake to 25% in 2012, and sold its remaining stake back to the company in 2013. Concurrently, the Carlyle Group replaced HTC as a minority shareholder, alongside Dr. Dre and Iovine in late 2013. In May 2014, Apple announced it would acquire Beats for $3 billion in a cash and stock deal, the largest acquisition in Apple's history. As of May 2025, Apple including Beats remained the global true wireless stereo (TWS) leader with 23% market share in Q1 of 2025.

##  History 
###  Formation 
Beats was established in 2006 by music producer Dr. Dre and record company executive Jimmy lovine. lovine perceived two key problems in the music industry: the impact of piracy on music sales and the substandard audio quality provided by Apple's plastic earbuds. Iovine recalled that Dre said to him: "Man, it's one thing that people steal my music. It's another thing to destroy the feeling of what I've worked on." Iovine sought the opinions of musicians with "great taste", such as M.I.A., Pharrell Williams, will.i.am, and Gwen Stefani during the early developmental stage. Beats initially partnered with inventor Noel Lee and his company Monster Cable, an audio and video component manufacturer based in Brisbane, California, to manufacture and develop the first Beats-branded products. The first product, Beats by Dr. Dre Studio headphones, debuted in 2008 with the mission to allow users to "hear what the artists hear".

To promote its products, Beats has featured celebrity endorsements by pop and hip-hop music performers, including product placement within music videos, and partnerships with musicians, fashion designers, athletes and other celebrities to develop co-branded products.

###  HTC purchase and non-renewal of Monster contract 
In August 2010, mobile phone manufacturer HTC acquired a 50.1% majority share in Beats for $309 million. The purchase was intended to allow HTC to compete with other cellphone makers by associating themselves with the Beats brand, as the purchase also granted HTC exclusive rights to manufacture smartphones with Beats-branded audio systems. Despite its majority acquisition, HTC allowed Beats to operate as an autonomous company. Luke Wood, who became President of Beats in May 2014, joined the company in January 2010 when it was still a "licensing business." Prior to this, Wood had worked under Iovine at Interscope Records.
In January 2012, BusinessWeek reported that Beats and Monster would not renew their production contract and their partnership ceased at the end of 2012. Dre and Iovine subsequently decided to oversee the entire operation of the company, from manufacturing to R&D, and aimed to double its workforce to around 300 employees. Monster would ultimately begin marketing its own competing line of premium headphones aimed towards an older demographic.
In October 2012, Beats unveiled its first two self-developed products, "Beats Executive" headphones and "Beats Pill" wireless speakers—Iovine believed the company would now have to "control [its] own destiny" to continue its growth. Iovine also commented on how other headphone makers had attempted to emulate Beats' celebrity endorsement business model (including Monster themselves, who unveiled Earth, Wind and Fire and Miles Davis-themed headphones at the 2012 Consumer Electronics Show), stating "some of our competitors are cheap engineers who have never been to a recording studio. You can't just stick someone's name on a headphone that doesn't know anything about sound." Following the decision to transform Beats into an autonomous entity, the company's revenues reached the $1 billion mark, according to Iovine.

###  HTC sale and Beats Music 
In July 2012, HTC sold back half of its stake in Beats for $150 million, remaining the largest shareholder with 25.1%. The sale was intended to provide "flexibility for global expansion while maintaining HTC's major stake and commercial exclusivity in mobile". In August 2013, reports surfaced that Beats' founders planned to buy back HTC's remaining minority stake in the company, and pursue a new, unspecified partner for a future investment.
In September 2013, HTC confirmed it would sell its remaining stake in Beats back to the company for $265 million. Concurrently, Beats announced the Carlyle Group would make a $500 million minority investment in the company. The overall deal valued Beats Electronics at $1 billion and helped HTC turn a net profit of $10.3 million for Q4 of 2013, following HTC's first quarterly loss in company history.
The appointment of a new chief operating officer (COO), a role previously filled by Wood, was announced in early November 2013. Matthew Costello, formerly of IKEA and HTC, was formally appointed to the role in May 2014.
In January 2014, the company launched Beats Music, a subscription-based online music streaming service. Prior to the launch of the service, Beats stated that it intended to provide a different type of streaming experience to what was available on the market at the time. Additionally, the service would only be available to consumers in the U.S. at inception.

###  Acquired by Apple Inc. (2014) 
In May 2014, the Financial Times reported that Apple was in negotiations with Beats to purchase the company for $3.2 billion—the largest purchase in Apple's history. The impending deal was prematurely and indirectly revealed in a photo and YouTube video posted to Facebook by Tyrese Gibson on May 8, 2014; the video documented a celebration in which Gibson and Dr. Dre made boasting remarks about the acquisition, with Dre declaring himself the "first billionaire in hip hop", while Gibson declared that the "Forbes list" had changed. Both the photo and video were removed from Facebook the following morning, but both remain on Gibson's YouTube channel. Indeed, analysts estimated that the rumored deal would make Dr. Dre the first billionaire in the hip-hop music industry in terms of net worth, assuming he held at least 15% ownership in the company prior to the deal. Dr. Dre was listed with a net worth of $550 million on Forbes' The World's Billionaires 2014 list. It was also estimated that the Carlyle Group would receive a profit of $1 billion from the sale of its minority stake in the company.
In May 2014, Apple officially announced its intention to acquire Beats Electronics for $3 billion, with Apple saying it would pay an initial $2.6 billion for Beats, and approximately $400 million "that will vest over time". Iovine felt that Beats had always "belonged" with Apple, as the company modeled itself after Apple's "unmatched ability to marry culture and technology". In regard to the deal, Apple CEO Tim Cook stated that "Music is such an important part of all of our lives and holds a special place within our hearts at Apple. That's why we have kept investing in music and are bringing together these extraordinary teams so we can continue to create the most innovative music products and services in the world."
The acquisition closed in August 2014. Dr. Dre and Iovine were hired as executive employees, and worked at Apple for years afterward. Beats Music users were prompted to switch to Apple Music following its launch in June 2015.
In April 2020, former Apple vice president of Music, Sports and Beats Oliver Schusser became the new head of Beats.

###  Bose lawsuit 
In July 2014, Bose Corporation sued Beats, alleging its "Studio" line incorporated noise cancellation technology that infringed five patents held by the company. Bose also sought an injunction that would ban the infringing products from being imported or sold in the U.S. The lawsuit was settled out of court in October 2014; the details were not disclosed.

###  Monster lawsuit 
In January 2015, Monster Inc. sued Beats for fraud, alleging the company had used illicit tactics to force Monster out of the venture while retaining rights to the technologies and products it had co-developed, and engaged in collusion to harm Monster's audio products business. Monster also alleged that Beats had partaken in anti-competitive practices with retailers to force those offering Beats products to not offer Monster's competing products.
In June 2015, The Wall Street Journal reported that in retaliation for the lawsuit, Apple revoked Monster's membership in the MFi Program in May 2015, meaning Monster could no longer manufacture licensed accessories for iPhone, iPod and iPad products, and must cease the sale of existing licensed products containing the certification or technology licensed through the program by September 2015.
The case was dismissed in August 2016, with a Supreme Court ruling that Beats "had the right to terminate the agreement".

##  Products 
Beats' original product line were Beats Studio headphones. In promotional materials, Dre outlined the line's advantages by alleging that listeners were not able to hear "all" of the music with most headphones, and that Beats would allow people to "hear what the artists hear, and listen to the music the way they should: the way I do". In comparison to most headphones, Beats products were characterized by an emphasis toward producing larger amounts of bass, and are particularly optimized toward hip-hop and pop music.
Recent Beats products are built with ecosystem features that support both Apple and Android users, with comparable native features like one-touch pairing and device-finding on each platform.

###  Headphones 
Beats Studio
After the initial launch of the Beats Studio headphones in 2008, Beats introduced the first wireless version of its noise-cancelling Beats Studio model in 2013.
Released in October 2017, Beats Studio3 Wireless headphones were produced until 2023, when they were replaced with the Beats Studio Pro. They connected by Bluetooth and had 40 hours of battery life, with 22 hours of battery life with adaptive noise cancelling on. They featured Apple's W1 chip for quick connection to compatible Apple devices. They also featured pure adaptive noise cancelling technology, which used microphones both inside and outside the ear cups to measure sound levels based on the environment.
Released in July 2023, Beats Studio Pro headphones featured noise cancellation and transparency mode, and are the first Beats to feature USB-C and lossless audio through USB-C connections. Being the fourth generation of Beats' popular Studio headphones, they also featured Personalized Spatial Audio with dynamic head tracking and were compatible with Find My when paired with compatible Apple devices.

####  Beats Solo 
In 2009, the first-generation Beats Solo headphones were released.
In 2010, the design team of Robert Brunner and Gregoire Vandenbussche; Chris Fruhauf; and David Leung and Dr. Dre were awarded an International Design Excellence Award for the Beats Solo headphones from the Industrial Designers Society of America. In his description, Ed Magnum of the University of Cincinnati noted: “Beats by Dr. Dre Solo brings pro audio to the everyday consumer, executing on all fronts of personal accessory design with quality sound, enhanced portability, comfort, and style."
In 2014, Beats Solo and Beats Solo Wireless headphones all received second-generation updates. Released in 2014, the Beats Solo2 Wireless was an on-ear style headphone. These were the more compact and wireless version of the classic Beats headphones, including noise isolation and big bass driver acoustic technology.
Released in 2016, the Beats Solo3 Wireless was an on-ear style headphone. It could last for 40 hours on a single charge or indefinitely when plugged in via the headphone jack. It had a Micro-USB connector for charging. It had a similar look to the previous version, but was 10 grams lighter, and was the first Beats headphone to use Apple's energy-saving W1 chip.
The Beats Solo Pro was an on-ear style headphone released in 2019. Along with the Powerbeats Pro true-wireless earphones, it was part of a new generation of Beats products made from the ground up with Apple. It was the first on-ear headphone made by Beats to feature active noise cancelling. They were sold alongside the Solo 3 until November 1, 2021.

Released in May 2024, the Beats Solo 4 are wireless on-ear headphones. They feature Personalized Spatial Audio with dynamic head tracking and lossless audio via USB-C or a 3.5mm cable. With up to 50 hours of battery life, they also give 5 hours of playback with a 10-minute charge. These headphones are compatible with both iOS and Android.

###  Earbuds 
In 2008, the Beats Tour headphones were released.
Powerbeats
The Beats Powerbeats line began in 2010 with the launch of the original Powerbeats, introduced in Partnership with Lebron James. In 2014, Beats released the Powerbeats² Wireless, which introduced Bluetooth connectivity to the line.
In September 2016, Powerbeats³ Wireless were released. Powerbeats Pro were released on May 10, 2019, in the U.S. and two weeks later for UK and Europe, becoming Beats' "first truly wireless workout headphones". The latest iteration of Powerbeats was released on March 18, 2020, sharing design concepts similar to that of the Powerbeats Pro from the year prior. In February 2025 Powerbeats Pro 2 were released, featuring heart rate monitoring for workouts.
Beats Studio Buds
In June 2021, Beats Studio Buds were released. In May 2023, Beats Studio Buds+ were released as a sequel to the original Beats Studio Buds.
Beats Solo Buds
Released in 2024, although visually similar to the Studio Buds and Buds+, these earbuds were less expensive and longer-lasting. They were also notable for their sound, fit, and compact design, with a charging case that was reported to be 40% smaller and 55% lighter than those of previous Beats earbuds.
BeatsX
In February 2017, BeatsX neckband-style headphones were released.
Beats Flex
In October 2020, Beats Flex neckband-style headphones were released as the evolution of BeatsX, featuring magnetic earbuds that allow the headphones to automatically pause playback when clipped together.
Beats Fit Pro
In November 2021, the Beats Fit Pro were released, featuring a novel "wingtip" earbud design to enhance stability during fitness workouts. In September 2025, Beats released Powerbeats Fit, an updated version of the Beats Fit Pro. The new version has a redesigned wingtip that is nearly 20% more flexible than previous versions.
urBeats
urBeats were wired in-ear headphones that were introduced in 2012. The product name first appeared publicly that year in connection with Beats-branded earbuds bundled with select HTC smartphones, prior to the broader retail release of the urBeats model. Beats subsequently released updated versions of the urBeats with revised designs and color options.

###  Speakers 
In 2012, Beats introduced their first speaker product, Beats Pill. In 2013, the Beats Pill was replaced by the Beats Pill 2 and a larger model, Beats Pill XL, was introduced. The Beats Pill XL was recalled and discontinued in mid-2015 due to battery safety concerns.
The Beats Pill 2 had a number of accessories available, including a bike mount and a speaker stand — the "Dude" — shaped like a small wide-mouthed person. The Beats Pill 2 was replaced by the Beats Pill+, the first Beats speaker made under Apple, which was introduced in late 2015 and discontinued in early 2021.
In October 2015, Beats launched a new collection of speakers including the upgraded Beats Pill+ Speaker.
Beats brought back the Beats Pill in June 2024. The redesigned speaker features a revised cylindrical form factor, updated materials, and a removable lanyard.

###  Accessories 
Beats’s accessories include Beats charging cables and iPhone cases.

###  Beats Audio 
The company has also licensed the Beats brand, under the name Beats Audio (stylized in lowercase as beats audio), and technology to other manufacturers. In 2009, HP began to offer personal computers equipped with Beats Audio systems, beginning with its HP Envy line. The system featured a software equalizer with a preset HP marketed as being optimized for higher quality sound output. Beats Electronics ceased its partnership with HP following its purchase by Apple Inc.; HP subsequently entered into a similar agreement with Bang & Olufsen.
Following its acquisition of a stake in the company, most new HTC smartphones began to be released with Beats Audio software, beginning with the HTC Sensation XE/XL with Beats Audio in September 2011. The software was to be included in most new HTC devices, such as the One series. The Sensation XE and Rezound were also bundled with Beats earbuds, but HTC abandoned the practice on future devices. An HTC product executive claimed that despite the prominence of the Beats brand, "an accessory like the headphone doesn't factor in when someone is buying a smartphone".

####  Car audio 
In 2011, Beats reached a deal with Chrysler LLC to feature Beats-branded audio systems in its vehicles. First under the partnership was its 2012 Chrysler 300S Luxury Car, which included a 10-speaker Beats sound system. Beats audio systems are also available in brands including Dodge and Jeep vehicles.
Other automobile brands that have Beats audio systems available in their vehicles include Fiat, Volkswagen and SEAT.

###  Beats Music 
In July 2012, Beats acquired the online music service MOG for $14 million, as part of the company's goal to develop a "truly end-to-end music experience". The acquisition did not include the company's blog and advertising network, the MOG Music Network, which was sold in a separate transaction to the broadcasting company Townsquare Media in August 2012.
While MOG indicated that it would continue to operate independently with no immediate change in service, Beats subsequently announced a new subscription-based online music service, known as Beats Music, which launched in January 2014. In comparison to competitors, such as Spotify and Google Play Music, the service emphasized recommendations by music professionals alongside algorithmic recommendations. MOG was shut down in May 2014, and existing users were directed to Beats Music. Beats Music was in turn replaced by Apple Music in June 2015; the service also incorporated a Beats-branded online radio station, called "Beats 1", but the name was later changed to "Apple Music 1".

###  Dolby Atmos Support 
In May 2021, Apple announced spatial audio with Dolby Atmos support. Apple Music automatically plays Dolby Atmos tracks on AirPods, AirPods Pro, AirPods Max, and all Beats headphones with an H1 or W1 chip.

##  Partnerships/Collaborations 
In the 2000s, as a result of Jimmy Iovine's role at Interscope Records, Beats headphones and speakers were featured in numerous Interscope music videos, including those by artists such as Lady Gaga, Miley Cyrus, and Nicki Minaj.
Beats has since collaborated with many musicians throughout the years, including Lil Wayne, DJ Khaled, Travis Scott, Pharrell Williams, and Jennie from K-pop girl group Blackpink. The brand has also collaborated with professional athletes such as LeBron James, Lionel Messi, Shohei Ohtani, as well as other high-profile celebrities like Kim Kardashian and Kylie Jenner.
Beats’ collaborations with specific brands have included partnerships with Alexander Wang, MCM (Modern Creation München), Fendi, Violet Grey, Balmain, and AMBUSH.

##  Campaigns 
“Hear What You Want” campaign
In 2013, Beats launched its “Hear What You Want” campaign with a spot featuring Kevin Garnett. The campaign’s first series of ads also featured San Francisco 49ers’ Colin Kaepernick, Seattle Seahawks’ Richard Sherman, and FC Barcelona’s Cesc Fábregas.
“Straight Outta” campaign
In 2015, Beats partnered with Interscope and Universal Pictures to help promote Universal’s N.W.A biopic, Straight Outta Compton (2015). This included the “Straight Outta Somewhere” meme that went viral.
NBA and Beats
In 2018, Beats and the National Basketball Association (NBA) announced a partnership making Beats the official headphone, wireless speaker and audio partner of the NBA, WNBA and USA Basketball, as well as the NBA development system the NBA G League. A new advertisement, titled “NBA and Beats,” starring LeBron James, James Harden, Ben Simmons, Draymond Green and Karl-Anthony Towns was released to accompany the partnership.
“Athletes Get It” campaign
In 2024, Beats’ “Athletes Get It” campaign featured Lionel Messi, LeBron James, Shohei Ohtani and narration by WNBA player Angel Reese.
“Listen to Your Heart” campaign
In 2025, Beats launched Powerbeats Pro 2, featuring NBA superstar LeBron James, MLS superstar Lionel Messi, and MLB superstar Shohei Ohtani in a post-Super Bowl ad voiced by RZA.

##  Critical reception 
Some critics claimed that Beats products emphasize appearance over quality and function, arguing that more durable and better-sounding products are available for the same price or lower.
Since its acquisition by Apple in 2014, Beats' perception has improved. In 2025, CNET reported that "Beats headphones and earbuds have come a long way in terms of sound quality."

##  Awards 
Beats Studio Pro won “best workout headphones” on the Rolling Stone Audio Awards 2024 list. In 2025, Powerbeats Pro 2 won the GQ Tech Award for “best workout headphone” and Beats Solo 4 won “best headphones” in the Women's Health Fitness Awards.

##  References 
##  External links 
Official website
