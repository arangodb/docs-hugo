# Andy Jassy

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/Andy_Jassy>*

Andrew R. Jassy (born January 13, 1968) is an American business executive who is the president and chief executive officer of Amazon since July 2021, succeeding founder Jeff Bezos, who remains executive chairman. Jassy founded and led Amazon Web Services (AWS) from its inception and served as its CEO from April 2016 until July 2021.

##  Early life 
Jassy is the son of Margery and Everett L. Jassy of Scarsdale, New York. Of Jewish Hungarian ancestry, his father was a senior partner in the corporate law firm Dewey Ballantine in New York City, and chairman of the firm's management committee. Jassy grew up in Scarsdale, and attended Scarsdale High School, where he played varsity soccer and tennis.
Jassy graduated cum laude from Harvard College in government, where he was advertising manager of The Harvard Crimson. He later earned an MBA from Harvard Business School. In 1989, he wrote in The Crimson that the newspaper should continue to publish advertisements from Eastern Air Lines, despite an ongoing labor dispute there.

##  Career 
Jassy worked for five years after graduation and before entering his MBA program, as a project manager for a collectibles company, MBI, and then he and an MBI colleague started a company and closed it down.
Jassy joined Amazon as a marketing manager in 1997. Early in his Amazon career, he helped run the company's first marketing team and later its compact disc business. He subsequently served as Jeff Bezos's first technical adviser, or "shadow", a role in which he accompanied Bezos to meetings and discussed potential business opportunities with him. In 2003, he and Bezos came up with the idea to create the cloud computing platform that became known as Amazon Web Services (AWS), which launched in 2006. Jassy headed AWS and its original team of 57 people.

In 2015, Jassy and Amazon executive James Hamilton helped lead Amazon's acquisition of Annapurna Labs, an Israeli semiconductor company whose technology became part of Amazon's effort to design its own data-center chips. In 2016, Jassy was promoted from senior vice president to chief executive officer of AWS. That year Jassy was paid $36.6 million.
In 2017, he was elected as a member of the American Academy of Arts and Sciences.
Jassy was a member of the National Security Commission on Artificial Intelligence (NSCAI), which was established in 2018 and issued its final report in March 2021.
In January 2021, Bezos designated Jassy his official successor as Amazon CEO; the transition occurred on July 5, 2021. During his first years as CEO, Jassy oversaw cost reductions and a reassessment of Amazon's pandemic-era expansion, including corporate layoffs, a return-to-office policy, and the closure or scaling back of some projects and physical-store initiatives.
As CEO of Amazon, Jassy received a ten-year pay package totaling $212.7 million. The majority of the compensation package was in stock and vests over 10 years. He held more than 2.160 million common shares of Amazon.com and was estimated to have a net worth of almost $500 million as of January 2025. In April 2025, Amazon's proxy statement disclosed that Jassy received total compensation of $40.1 million in 2024.
As CEO, Jassy emphasized Amazon's focus on artificial intelligence (AI), particularly through AWS infrastructure, generative AI services, and Amazon-designed chips such as Trainium. Amazon said it planned to spend more than $75 billion on capital expenditures in 2025, with most of that investment directed toward AWS and generative AI. In his 2025 shareholder letter, Jassy wrote that Amazon expected approximately $200 billion in capital expenditures in 2026 and said the spending was supported in part by customer commitments for AWS capacity.
Under Jassy, Amazon also expanded its partnerships with major AI companies. In February 2026, Amazon and OpenAI announced an expansion of their existing $38 billion multi-year agreement by $100 billion over eight years, including OpenAI's commitment to use approximately 2 gigawatts of AWS Trainium capacity. In April 2026, Amazon and Anthropic announced an expanded collaboration under which Anthropic committed to spend more than $100 billion over ten years on AWS technologies, while Amazon agreed to invest $5 billion immediately and up to $20 billion more in Anthropic, in addition to its earlier $8 billion investment.
Jassy is a member of The Business Council.

##  Personal life 
In 1997, Jassy married Elana Rochelle Caplan, a fashion designer for Eddie Bauer and graduate of the Philadelphia College of Textiles and Science, at a Loews Hotel in Santa Monica, California.  Their wedding was officiated by New York reform Rabbi James Brandt, a cousin of Elana. Both their fathers were senior partners in law firm Dewey Ballantine. Jassy and Caplan have two children.
They live in the Capitol Hill neighborhood of Seattle in a 10,000-square-foot house bought in 2009 for $3.1 million. In October 2020, it was reported that Jassy had bought a $6.7 million 5,500-square-foot house in Santa Monica.
Jassy serves on the Trust of the American Academy of Arts and Sciences, on the Board of Trustees for Rainier Scholars, and as chair of Rainier Prep's board of directors.

##  Awards and honors 
In 2016, Jassy was named Person of the Year by the Financial Times.
In 2025, Time magazine included Jassy in its TIME100 AI list. That same year, Jassy was elected to the National Academy of Engineering.

##  References
