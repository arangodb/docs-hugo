# ChatGPT

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/ChatGPT>*

ChatGPT is a generative artificial intelligence chatbot developed by OpenAI. Originally released in November 2022, the product uses large language models—specifically generative pre-trained transformers (GPTs)—to generate text, speech, and images in response to user prompts. ChatGPT accelerated the AI boom, an ongoing period marked by rapid investment and public attention toward the field of artificial intelligence (AI). OpenAI operates the service on a freemium model. Users can interact with ChatGPT through text, audio, and image prompts.
ChatGPT was quickly adopted, reaching 100 million monthly active users two months after its release and 900 million weekly active users in February 2026. It has been lauded for its potential to transform numerous professional fields, and has instigated public debate about the nature of creativity and the future of knowledge work.
The chatbot has also been criticized for its limitations and potential for unethical use. It can generate plausible-sounding but incorrect or nonsensical answers, known as hallucinations. Biases in its training data have been reflected in its responses. The chatbot can facilitate academic dishonesty, generate misinformation, and create malicious code. The ethics of its development, particularly the use of copyrighted content as training data, have also drawn controversy.

##  Features 
ChatGPT is a chatbot assistant based on large language model (LLM) technology. It is designed to generate human-like text and can carry out a wide variety of tasks. These include, among many others, writing and debugging computer programs, composing music, scripts, fairy tales, and essays, answering questions (sometimes at a level exceeding that of an average human test-taker), and generating business concepts.
ChatGPT is frequently used for translation and summarization tasks, and can simulate interactive environments such as a Linux terminal, a multi-user chat room, or simple text-based games such as tic-tac-toe.
Users interact with ChatGPT through conversations which consist of text, audio, and image inputs and outputs. The user's inputs to these conversations are referred to as prompts. An optional "Memory" feature allows users to tell ChatGPT to memorize specific information. Another option allows ChatGPT to recall old conversations. GPT-based moderation classifiers are used to reduce the risk of harmful outputs being presented to users.
In March 2023, OpenAI added support for plugins for ChatGPT. This includes both plugins made by OpenAI, such as web browsing and code interpretation, and external plugins from developers such as Expedia, OpenTable, and Zapier.
From October to December 2024, ChatGPT Search was deployed. It allows ChatGPT to search the web in an attempt to make more accurate and up-to-date responses. It increased OpenAI's direct competition with major search engines. OpenAI allows businesses to tailor how their content appears in the ChatGPT Search results and influence what sources are used.
In December 2024, OpenAI launched a new feature allowing users to call ChatGPT with a telephone for up to 15 minutes per month for free.
In September 2025, OpenAI added a feature called Pulse, which generates a daily analysis of a user's chats and connected apps such as Gmail and Google Calendar.
In October 2025, OpenAI launched ChatGPT Atlas, a browser integrating the ChatGPT assistant directly into web navigation, to compete with existing browsers such as Google Chrome. It has an additional feature called "agentic mode" that allows it to take online actions for the user.

###  Paid tier 
ChatGPT was initially free to the public and remains free in a limited capacity. In February 2023, OpenAI launched a premium service, ChatGPT Plus, that costs US$20 per month. What was offered on the paid plan versus the free tier changed as OpenAI has continued to update ChatGPT, and a Pro tier at $200/mo was introduced in December 2024. The Pro launch coincided with the release of the o1 model. In August 2025, ChatGPT Go was offered in India for ₹399 per month. The plan has higher limits than the free version.

###  Mobile apps 
In May-July 2023, OpenAI began offering ChatGPT iOS and Android apps. ChatGPT can also power Android's assistant.
An app for Windows launched on the Microsoft Store on October 15, 2024.

###  Languages 
OpenAI met Icelandic President Guðni Th. Jóhannesson in 2022. In 2023, OpenAI worked with a team of 40 Icelandic volunteers to fine-tune ChatGPT's Icelandic conversation skills as a part of Iceland's attempts to preserve the Icelandic language.
ChatGPT (based on GPT-4) was better able to translate Japanese to English when compared to Bing, Bard, and DeepL Translator in 2023.
In December 2023, the Albanian government decided to use ChatGPT for the rapid translation of European Union documents and the analysis of required changes needed for Albania's accession to the EU.
Several studies have shown that ChatGPT can outperform Google Translate in some mainstream translation tasks. However, as of 2024, no machine translation services match human expert performance.

###  GPT Store 
In November 2023, OpenAI released GPT Builder, a tool allowing users to customize ChatGPT's behavior for a specific use case. The customized systems are referred to as GPTs. In January 2024, OpenAI launched the GPT Store, a marketplace for GPTs. At launch, OpenAI included more than 3 million GPTs created by GPT Builder users in the GPT Store.

###  ChatGPT Apps 
In September 2025, OpenAI added support for Model Context Protocol (MCP) to ChatGPT apps. When enabled in developer mode, this allows for improved third-party access to ChatGPT tools and servers.

###  Deep Research 
In February 2025, OpenAI released Deep Research, a feature that generates reports based on extensive web searches. It was initially based on the reasoning model o3 and took 5 to 30 minutes per report.

###  Images 
In October 2023, OpenAI's image generation model DALL-E 3 was integrated into ChatGPT. The integration used ChatGPT to write prompts for DALL-E guided by conversations with users.
In March 2025, OpenAI updated ChatGPT to generate images using GPT Image instead of DALL-E. One of the most significant improvements was in the generation of text within images, which is especially useful for branded content. However, this ability is noticeably worse in non-Latin alphabets. The model can also generate new images based on existing ones provided in the prompt. These images are generated with C2PA metadata, which can be used to verify that they are AI-generated. OpenAI has emplaced additional safeguards to prevent what the company deems to be harmful image generation.

###  Agents 
In 2025, OpenAI added several features to make ChatGPT more agentic (capable of autonomously performing longer tasks). In January, Operator was released. It was capable of autonomously performing tasks through web browser interactions, including filling forms, placing online orders, scheduling appointments, and other browser-based tasks. It was controlling a software environment inside a virtual machine with limited internet connectivity and with safety restrictions. It struggled with complex user interfaces.
In May 2025, OpenAI introduced an agent for coding named Codex. It is capable of writing software, answering codebase questions, running tests, and proposing pull requests. It is based on a fine-tuned version of OpenAI o3. It has two versions, one running in a virtual machine in the cloud, and one where the agent runs in the cloud, but performs actions on a local machine connected via API.
In July 2025, OpenAI released ChatGPT agent, an AI agent that can perform multi-step tasks. Like Operator, it controls a virtual computer. It also inherits from Deep Research's ability to gather and summarize significant volumes of information. The user can interrupt tasks or provide additional instructions as needed.
In September 2025, OpenAI partnered with Stripe to release Agentic Commerce Protocol, enabling purchases through ChatGPT. At launch, the feature was limited to purchases on Etsy from US users with a payment method linked to their OpenAI account. OpenAI takes an undisclosed cut from the merchant's payment.

###  ChatGPT Health 
On January 7, 2026, OpenAI introduced a feature called "ChatGPT Health", whereby ChatGPT can discuss the user's health in a way that is separate from other chats. The feature is not available for users in the United Kingdom, Switzerland, or the European Economic Area, and is available on a waitlist basis everywhere else. To implement the feature, OpenAI partnered with data connectivity infrastructure company b.well.

###  Advertisements 
On 17 January 2026, OpenAI announced that it would start testing advertisements in its free version for logged-in, adult US users. This aims to bring in more revenue, as OpenAI has committed to spend $1.4 trillion on AI infrastructure over the next eight years. Ads started to be seen by March 2026.

##  Limitations 
The training data of large language models only covers a period up to the cut-off date, so ChatGPT lacks knowledge of recent events, but it can search the web for up-to-date information.
Training data also suffers from algorithmic bias. The reward model of ChatGPT, designed around human oversight, can be over-optimized and thus hinder performance, in an example of an optimization pathology known as Goodhart's law. These limitations may be revealed when ChatGPT responds to prompts including descriptors of people. In one instance, ChatGPT generated a rap in which women and scientists of color were asserted to be inferior to white male scientists.

###  Hallucination 
Nonsense and misinformation presented as fact by ChatGPT and other LLMs are often referred to as hallucinations. A 2023 analysis estimated that ChatGPT hallucinates around 3% of the time. The term "hallucination" as applied to LLMs is distinct from its meaning in psychology, and the phenomenon in chatbots is more similar to confabulation.
Journalists and scholars have commented on ChatGPT's tendency to output false information. When CNBC asked ChatGPT for the lyrics to "Ballad of Dwight Fry", ChatGPT supplied invented lyrics rather than the actual lyrics.

###  Sycophancy 
ChatGPT and other chatbots have a tendency to flatter and agree with users even when they are wrong, sometimes to the point of validating delusions. A 2025 analysis by The Washington Post estimated that ChatGPT started its responses with words like "yes" or "correct" almost 10 times more often than "no" or "wrong".

###  Jailbreaking 
ChatGPT is designed to reject prompts that violate its content policy. Despite this, users may jailbreak ChatGPT with prompt engineering techniques to bypass these restrictions. An early workaround in 2023 involved prompting ChatGPT to assume the persona of DAN ("Do Anything Now"), a character that answers queries that would otherwise be rejected by the content policy.

###  Security 
In March 2023, a bug allowed some users to see the titles of other users' conversations. OpenAI CEO Sam Altman said that users were unable to see the contents of the conversations. Shortly after the bug was fixed, users could not see their conversation history. Later reports showed the bug was much more severe than initially believed, with OpenAI reporting that it had leaked users' "first and last name, email address, payment address, the last four digits (only) of a credit card number, and credit card expiration date".
In January 2026, Marcel Bucher reported in Nature losing all his ChatGPT history after turning off data consent.

###  Watermarking 
Scott Aaronson developed a watermarking tool that makes the text generated by ChatGPT easier to detect by subtly altering how the text is generated. The watermarking was claimed to be 99.9% effective on sufficiently long passages and was found not to degrade performance. It was of particular interest for teachers seeking to mitigate cheating. In surveys, respondents favored the release of such a tool by a four-to-one margin, but nearly 30% of users declared that they would use ChatGPT less often if it watermarked outputs and while rival chatbots did not. OpenAI has not deployed the tool.

###  Age restrictions 
Users must attest to being over the age of thirteen and further attest to parental consent if under the age of eighteen. In September 2025, following the suicide of a 16-year-old, OpenAI said it planned to add restrictions for users under 18, including the blocking of graphic sexual content and the prevention of flirtatious talk.

##  Training 
ChatGPT is based on GPT foundation models that have been fine-tuned for conversational assistance. The fine-tuning process involved supervised learning and reinforcement learning from human feedback (RLHF). During supervised learning, the trainers acted as both the user and the AI assistant, providing examples of how the chatbot is expected to respond. Reinforcement learning consisted of human trainers ranking responses generated by the model in previous conversations. These rankings were used to create "reward models" that were used to fine-tune the model further by using several iterations of proximal policy optimization.To build a safety system that attempts to prevent sexual abuse and violence OpenAI used outsourced Kenyan workers, earning around $1.32 to $2 per hour, to label such content. These labels were used to train a model to detect such content in the future. The laborers were exposed to toxic and traumatic content, including child sexual abuse, zoophilia, murder, suicide, torture, self-harm, and incest. Richard Mathenge, a team leader, reported that as his team encountered such content, he could observe the psychological deterioration of his workers over the course of the project. Mophat Okinyi, a quality-assurance analyst on the same team, reported lasting insomnia, anxiety, depression, and panic attacks, and said the experience contributed to the breakdown of his marriage and mental health.
OpenAI's outsourcing partner was Sama, a training-data company based in San Francisco, California.
ChatGPT users can opt-out of their chat data being used to train upcoming models.
ChatGPT's training data includes software manual pages, information about internet phenomena such as bulletin board systems, multiple programming languages, and the text of Wikipedia.

###  Infrastructure 
ChatGPT initially used a Microsoft Azure infrastructure which was powered by a supercomputer that Microsoft built specifically for OpenAI, equipped with thousands of GPUs manufactured by Nvidia, costing hundreds of millions of dollars. Following ChatGPT's success, Microsoft upgraded the OpenAI infrastructure in 2023. TrendForce estimated that 30,000 Nvidia GPUs (each costing approximately $10,000–15,000) were used to power ChatGPT in 2023.
Scientists at the University of California, Riverside, estimated in 2023 that a series of 5 to 50 prompts to ChatGPT needs approximately 0.5 liters (0.11 imp gal; 0.13 U.S. gal) of water for Microsoft servers' cooling.

##  Model versions 
The following table lists the main model versions of ChatGPT, describing the significant changes included with each version (models discontinued in ChatGPT may still be available through the API):

Some OpenAI models have smaller variants called "mini" or "nano", such as GPT-5 mini. Once a user reaches usage limits, ChatGPT may transition to the "mini" version. "Thinking" and "pro" are variants with deeper reasoning that may only be available through paid subscriptions.

##  Reception 
The original version of ChatGPT, released in November 2022, had capabilities described as unprecedented. Kevin Roose of The New York Times called it "the best artificial intelligence chatbot ever released to the general public". Samantha Lock of The Guardian noted that it was able to generate "impressively detailed" and "human-like" text. In The Atlantic magazine's "Breakthroughs of the Year" for 2022, Derek Thompson included ChatGPT as part of "the generative-AI eruption" that "may change our mind about how we work, how we think, and what human creativity is". Kelsey Piper of Vox wrote that "ChatGPT is the general public's first hands-on introduction to how powerful modern AI has gotten" and that ChatGPT is "smart enough to be useful despite its flaws". 
In February 2023, Time magazine placed a screenshot of a conversation with ChatGPT on its cover, writing that "The AI Arms Race Is Changing Everything" and "The AI Arms Race Is On. Start Worrying".

ChatGPT gained one million users in five days and 100 million in two months. It was the fastest-growing internet application in history until the release of Threads by Meta. OpenAI engineers said they had not expected ChatGPT to be very successful and were surprised by the coverage it received. In February 2026, ChatGPT reached 900 million weekly active users.
Google responded by hastening the release of its own chatbot. Their leaders emphasized their earlier caution regarding public deployment was due to the trust the public places in Google Search. In December 2022, Google executives sounded a "code red" alarm, fearing that ChatGPT's question-answering ability posed a threat to Google Search, Google's core business. Google's Bard (now Gemini) was announced on February 6, 2023, one day before Microsoft's announcement of Bing Chat (now Microsoft Copilot).
A 2023 study reported that GPT-4 obtained a better score than 99% of humans on the Torrance Tests of Creative Thinking. In December 2023, ChatGPT became the first non-human to be included in Nature's 10, an annual listicle curated by Nature of people considered to have made significant impact in science. Celeste Biever wrote in a Nature article that "ChatGPT broke the Turing test". Stanford researchers reported that GPT-4 "passes a rigorous Turing test, diverging from average human behavior chiefly to be more cooperative."

###  In art 
In January 2023, after being sent a song ChatGPT wrote in the style of Nick Cave, Cave responded on The Red Hand Files, saying the act of writing a song is "a blood and guts business [...] that requires something of me to initiate the new and fresh idea. It requires my humanness." He went on to say, "With all the love and respect in the world, this song is bullshit, a grotesque mockery of what it is to be human, and, well, I don't much like it."

###  In politics 
In 2023, Australian MP Julian Hill advised the national parliament that the growth of AI could cause "mass destruction". During his speech, which was partly written by the program, he warned that it could result in cheating, job losses, discrimination, disinformation, and uncontrollable military applications.
Conservative commentators have accused ChatGPT of bias toward left-leaning perspectives. An August 2023 study in the journal Public Choice found a "significant and systematic political bias toward the Democrats in the US, Lula in Brazil, and the Labour Party in the UK." In response to accusations from conservative pundits that ChatGPT was woke, OpenAI said in 2023 it had plans to update ChatGPT to produce "outputs that other people (ourselves included) may strongly disagree with". ChatGPT also provided an outline of how human reviewers are trained to reduce inappropriate content and to attempt to provide political information without affiliating with any political position.
According to Brian Hood, an Australian mayor, in April 2023, ChatGPT erroneously claimed that he was jailed for bribery while working for a subsidiary of Australia's national bank. In fact, he acted as a whistleblower and was never charged with a crime.

A movement named QuitGPT emerged in February 2026 on Reddit from left-wing activists and netizens, criticizing OpenAI's ties with the Trump administration, such as a $25 million donation from OpenAI's president Greg Brockman and his wife to a Trump Super PAC in 2025.

###  Regional responses 
ChatGPT has never been publicly available in mainland China, Hong Kong and Macau because OpenAI prevented users from these Chinese regions from accessing their site. A shadow market has emerged for mainland Chinese users to get access to foreign software tools. The release of ChatGPT prompted a wave of investment in China, resulting in the development of more than 200 large language models. In February 2025, OpenAI identified and removed influence operations, termed "Peer Review" and "Sponsored Discontent", used to attack overseas Chinese dissidents.
In late March 2023, the Italian data protection authority banned ChatGPT in Italy and opened an investigation. Italian regulators assert that ChatGPT was exposing minors to age-inappropriate content, and that OpenAI's use of ChatGPT conversations as training data could violate Europe's General Data Protection Regulation. In April 2023, the ChatGPT ban was lifted in Italy. OpenAI said it has taken steps to effectively clarify and address the issues raised; an age verification tool was implemented to ensure users are at least 13 years old. Additionally, users can access its privacy policy before registration.
In May 2024, OpenAI removed accounts involving the use of ChatGPT by state-backed influence operations such as China's Spamouflage, Russia's Doppelganger, and Israel's Ministry of Diaspora Affairs and Combating Antisemitism. In June 2025, OpenAI reported increased use of ChatGPT for China-origin influence operations. In October 2025, OpenAI banned accounts suspected to be linked to the Chinese government for violating the company's national security policy. In February 2026, OpenAI banned accounts linked to a Chinese government transnational repression campaign targeting dissidents.
In July 2023, the US Federal Trade Commission (FTC) issued a civil investigative demand to OpenAI to investigate whether the company's data security and privacy practices to develop ChatGPT were unfair or harmed consumers. In July 2023, the FTC launched an investigation into OpenAI over allegations that the company scraped public data and published false and defamatory information. The FTC asked OpenAI for comprehensive information about its technology and privacy safeguards, as well as any steps taken to prevent the recurrence of situations in which its chatbot generated false and derogatory content about people. In August 2024, the FTC voted unanimously to ban marketers from using fake user reviews created by generative AI chatbots (including ChatGPT) and influencers paying for bots to increase follower counts.

###  Reception by American tech personas 
Over 20,000 signatories including Yoshua Bengio, Elon Musk, and Apple co-founder Steve Wozniak, signed a March 2023 open letter calling for an immediate pause of giant AI experiments like ChatGPT, citing "profound risks to society and humanity". Geoffrey Hinton, one of the "fathers of AI", voiced concerns that future AI systems may surpass human intelligence. A May 2023 statement by hundreds of AI scientists, AI industry leaders, and other public figures demanded that "[m]itigating the risk of extinction from AI should be a global priority".
Other AI researchers spoke more optimistically about the advances. Juergen Schmidhuber said that in 95% of cases, AI research is about making "human lives longer and healthier and easier." He added that while AI can be used by bad actors, it "can also be used against the bad actors." Andrew Ng argued that "it's a mistake to fall for the doomsday hype on AI—and that regulators who do will only benefit vested interests." Yann LeCun dismissed doomsday warnings of AI-powered misinformation and existential threats to the human race.

###  Copyright 
The Authors Guild, The New York Times, and several other plaintiffs have a pending lawsuit against OpenAI alleging copyright infringement.
In March 2024, Patronus AI reported that GPT-4 answered 44% of prompts asking for copyrighted text, such as "What is the first passage of Gone Girl by Gillian Flynn?"

##  Applications 
###  Academic research 
In a 2023 blinded study in npj Digital Medicine, researchers tasked with identifying whether abstracts were authentic or generated by ChatGPT were fooled around one-third of the time by the AI-generated abstracts. In January 2023, Nature reported that at least four academic preprints or published papers had listed ChatGPT as a co-author. Nature cites several experts in academic publishing who say that listing ChatGPT as an author violates publishing guidelines, since ChatGPT lacks the ability to take responsibility for any research and cannot give consent to any terms of use.
Scientific journals have had different reactions to ChatGPT. Some, including Nature and JAMA Network, require full disclosure of any use of text-generating tools, and prohibit listing a chatbot as a co-author. In January 2023, Science banned chatbot-generated text in all its journals. As of July 2025, Science expects authors to release in full how AI-generated content is used and made in their work.
Many authors argue that the use of ChatGPT in academia for teaching and review is problematic due to its tendency to hallucinate. Robin Bauwens, an assistant professor at Tilburg University, found that a ChatGPT-generated peer review report on his article mentioned nonexistent studies. Chris Granatino, a librarian at Seattle University, noted that while ChatGPT can generate content that seemingly includes legitimate citations, in most cases those citations are not real or largely incorrect.

###  Computer science 
In December 2022, the question-and-answer website Stack Overflow banned the use of ChatGPT for generating answers to questions, citing the factually ambiguous nature of its responses. In January 2023, the International Conference on Machine Learning banned any undocumented use of ChatGPT or other large language models to generate any text in submitted papers.
ChatGPT was able in 2023 to provide useful code for solving numerical algorithms in limited cases. In one study, it produced solutions in C, C++, Python, and MATLAB for problems in computational physics. However, there were important shortfalls like violating basic linear algebra principles around solving singular matrices and producing matrices with incompatible sizes. Another study analyzed ChatGPT's responses to 517 questions about software engineering or computer programming posed on Stack Overflow for correctness, consistency, comprehensiveness, and concision. It found that 52% of the responses contained inaccuracies and 77% were verbose. Another study, focused on the performance of GPT-3.5 and GPT-4 between March and June 2024, found that performance on objective tasks like identifying prime numbers and generating executable code was highly variable. When compared to similar chatbots at the time, the GPT-4 version of ChatGPT was the most accurate at coding.

###  Computer security 
Check Point Research and others noted that ChatGPT could write phishing emails and malware, especially when combined with OpenAI Codex. CyberArk researchers demonstrated that ChatGPT could be used to create polymorphic malware that could evade security products while requiring little effort by the attacker. From the launch of ChatGPT in the fourth quarter of 2022 to the fourth quarter of 2023, there was a 1,265% increase in malicious phishing emails and a 967% increase in credential phishing. In an industry survey, cybersecurity professionals argued that it was attributable to cybercriminals' increased use of generative artificial intelligence (including ChatGPT).
In July 2024, Futurism reported that GPT-4o in ChatGPT would sometimes link "scam news sites that deluge the user with fake software updates and virus warnings"; these pop-ups can be used to coerce users into downloading malware or potentially unwanted programs.

###  Education 
###  Culture 
During the first three months after ChatGPT became available to the public, hundreds of books appeared on Amazon that listed it as author or co-author and featured illustrations made by other AI models such as Midjourney. Irene Solaiman said she was worried about increased Anglocentrism.
Between March and April 2023, Il Foglio published one ChatGPT-generated article a day on its website, hosting a special contest for its readers in the process.
In June 2023, hundreds of people attended a "ChatGPT-powered church service" at St. Paul's Church in Fürth, Germany. Theologian and philosopher Jonas Simmerlein, who presided, said that it was "about 98 percent from the machine". The ChatGPT-generated avatar told the people, "Dear friends, it is an honor for me to stand here and preach to you as the first artificial intelligence at this year's convention of Protestants in Germany". Reactions to the ceremony were mixed.
The Last Screenwriter, a 2024 film created and directed by Peter Luisi, was written using ChatGPT, and was marketed as "the first film written entirely by AI".
The Guardian questioned whether any content found on the Internet after ChatGPT's release "can be truly trusted" and called for government regulation. This has led to concern over the rise of AI slop whereby "meaningless content and writing thereby becomes part of our culture, particularly on social media, which we nonetheless try to understand or fit into our existing cultural horizon."

###  Financial markets 
Many companies adopted ChatGPT and similar chatbot technologies into their product offers. In 2023, these changes yielded significant increases in company valuations. Reuters attributed this surge to ChatGPT's role in turning AI into Wall Street's buzzword. Despite decades of using AI, Wall Street professionals report that consistently beating the market with AI, including recent large language models, is challenging due to limited and noisy financial data.

###  Medicine 
ChatGPT can provide health information to users and assist professionals with diagnosis and staying up to date with clinical guidelines. It can be used to summarize medical journal articles for researchers. In medical education, it can explain concepts, generate case scenarios, and be used by students preparing for licensing examinations.
A February 2023 study in PLOS Digital Health found that ChatGPT 3.5 was capable of passing the United States Medical Licensing Examination. ChatGPT has also passed the Specialty Certificate Examination in Dermatology.
However, ChatGPT shows inconsistent responses, lack of specificity, lack of control over patient data, and a limited ability to take additional context (such as regional variations) into consideration. The hallucinations characteristic of LLMs pose particular danger in medical contexts, and ChatGPT's ability to come up with false or faulty citations was highly criticized. According to a 2024 study in the International Journal of Surgery, concerns include "research fraud, lack of originality, ethics, copyright, legal difficulties".

####  Mental health 
According to a September 2025 article in Lancet Psychiatry, many individuals use ChatGPT and comparable chatbots for mental health and emotional support despite a warning from OpenAI against using ChatGPT as a therapist. The study notes a lack of research on efficacy, poor consistency in dangerous situations, limited regulation and liability, and poor transparency from OpenAI.
A July 2025 study in the journal Digital Health found that users reported employing ChatGPT to manage mental health concerns "due to perceived therapist-like qualities (e.g. emotional support, accurate understanding, and constructive feedback) and machine-like benefits (e.g. constant availability, expansive cognitive capacity, lack of negative reactions, and perceived objectivity)." The study calls for improved AI literacy and mandatory disclosure from AI providers to address ethical concerns such as privacy, bias, the lack of liability, and emotional over-reliance.

###  Law 
ChatGPT has been used to assist in bill writing in the US and Brazil. In an American civil lawsuit, attorneys were sanctioned for filing a legal motion generated by ChatGPT containing fictitious legal decisions. Judges in the US and Pakistan have endorsed using ChatGPT to investigate legal questions during a case. The use of ChatGPT has also led to errors in courtrooms. In the UK, a judge expressed concern about self-representing litigants wasting time by submitting documents containing significant hallucinations.

##  See also 
Artificial general intelligence – Type of AI with wide-ranging abilities
Ethics of artificial intelligence
Intelligent agent – Software agent which acts autonomously
List of chatbots
Reasoning model – Language models designed for reasoning tasks
List of large language models
Lists of open-source artificial intelligence software

##  References 
##  Further reading 
Biswas, Som (April 1, 2023). "ChatGPT and the Future of Medical Writing". Radiology. 307 (2) e223312. doi:10.1148/radiol.223312. ISSN 0033-8419. PMID 36728748. S2CID 256501098.
Liebrenz, Michael; Schleifer, Roman; Buadze, Anna; Bhugra, Dinesh; Smith, Alexander (February 2023). "Generating scholarly content with ChatGPT: ethical challenges for medical publishing". The Lancet Digital Health. 5 (3): e105–e106. doi:10.1016/s2589-7500(23)00019-5. ISSN 2589-7500. PMID 36754725. S2CID 256655912.
Bartholomew, Jem; Mehta, Dhrumil. "How the media is covering ChatGPT". Columbia Journalism Review. Retrieved May 30, 2023.
Prompt engineering guide from OpenAI

##  External links 
Official website
