# DoubleClick

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/DoubleClick>*

DoubleClick Inc. was an American online advertisement company that developed and provided Internet ad serving services from 1995 until its acquisition by Google in March 2008. DoubleClick offered technology products and services that were sold primarily to advertising agencies and mass media, serving businesses like Microsoft, General Motors, Coca-Cola, Motorola, L'Oréal, Palm, Inc., Apple Inc., Visa Inc., Nike, Inc., and Carlsberg Group. The company's main product line was known as DART (Dynamic Advertising, Reporting, and Targeting), which was intended to increase the purchasing efficiency of advertisers and minimize unsold inventory for publishers.
DoubleClick was founded in 1995 by Kevin O'Connor and Dwight Merriman and had headquarters in New York City, United States. It was acquired by private equity firms Hellman & Friedman and JMI Equity in July 2005. On March 11, 2008, Google acquired DoubleClick for $3.1 billion. In June 2018, Google announced plans to rebrand its ads platforms, and DoubleClick was merged into the new Google Marketing Platform brand. DoubleClick Bid Manager became Display and Video 360, DoubleClick Search became Search Ads 360, DoubleClick Campaign Manager became Campaign Manager 360 and DoubleClick for Publishers (DFP) became Google Ad Manager 360.

##  History 
In 1995, Kevin O'Connor and Dwight Merriman developed the concept for DoubleClick in O'Connor's basement. They created a system to display banner ads across a network of websites and track their performance to better target internet users. The product caught the attention of entrepreneur Kevin Ryan, who later joined as the company's CFO and later became its CEO.
Later that year, O'Connor and Merriman met Fergus O'Daily, the CEO of Poppe Tyson. Poppe Tyson had created an Interactive Sales division, but lacked the technology to deliver online ads across its network of client's sites. O'Connor, Merriman, and O'Daily decided to merge the two companies. To prevent competition from each company's sales teams, in November 1995 DoubleClick was spun off as an independent, wholly owned subsidiary. DoubleClick was founded as one of the earliest known Application Service Providers (ASP) for internet "ad-serving"—primarily banner ads.
In February 1998, during the dot-com bubble, the company became a public company, trading on NASDAQ under the symbol DCLK, via an initial public offering. Shares rose 75% on the first day of trading.
In June 1999, DoubleClick acquired Abacus Direct, which marketed consumer-purchasing data to catalog firms.
In July 1999, DoubleClick acquired NetGravity and rebranded NetGravity AdServer as DART Enterprise.
As of 2002, DoubleClick faced six lawsuits, including class-action lawsuits, related to invasions of privacy. Privacy groups complained that DoubleClick's plan to combine its online profiling information with offline information gathered by Abacus Direct would violate privacy rules, including the Stored Communications Act, the Wiretap Statute, and the Computer Fraud and Abuse Act, as it would allow the company to match a person's identity with their online habits, which it tracks through cookies. In February 2000, the FTC announced it had launched an investigation into the matter. The investigation was concluded in January 2001, with the FTC stating that it found no evidence that DoubleClick used or disclosed consumers personal identifying information. DoubleClick eventually entered into a settlement agreement where DoubleClick was required to explain its privacy policy in "easy-to-read" language; conduct a public information campaign consisting of 300 million banner ads inviting consumers to learn more about protecting their privacy; and institute data purging and opt-in procedures among other requirements.
In 2004, DoubleClick acquired Performics, which offered affiliate marketing, search engine optimization, and search engine marketing products. These products were integrated into the core DART system and rebranded DART search. DoubleClick Advertising Exchange connected both media buyers and sellers on an advertising exchange much like the financial negotiations of listed companies' capital stock. Google sold Performics in 2008 to Publicis.
In April 2005, Hellman & Friedman, a San Francisco-based private equity firm, agreed to acquire the company for $1.1 billion.

##  Acquisition by Google 
On April 13, 2007, Google agreed to acquire DoubleClick for US$3.1 billion in cash. The deal raised concerns surrounding competition with both the Federal Trade Commission (FTC) and the European Union. In May 2007, the FTC requested additional information about the deal after it was urged by competitors, including Microsoft, which believed it would give Google too much control over online advertising. On December 20, 2007, the FTC approved Google's purchase of DoubleClick from its owners Hellman & Friedman and JMI Equity. European Union regulators approved on March 11, 2008, and Google completed the acquisition later that day. On April 2, 2008, Google announced it would cut 300 jobs at DoubleClick due to organizational redundancies. Selected employees would be matched within the Google organization as per position and experience.
In November 2007, shortly after the announcement of the acquisition, it was reported that DoubleClick had been serving ads designed to trick users into buying malware. This occurred after a malicious website tricked several name-brand websites into serving the ads.
 

In June 2010, Google confirmed its acquisition of Invite Media, a demand-side platform, which it later renamed DoubleClick Bid Manager.
On July 24, 2018, the names and logos of all DoubleClick products were updated, and DoubleClick Bid Manager is now Display & Video 360 (DV360).

##  See also 
Surveillance capitalism

##  References 
##  External links 
Official website at the Wayback Machine (archived 2006-07-17)
