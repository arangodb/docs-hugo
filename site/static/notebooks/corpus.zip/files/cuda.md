# CUDA

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/CUDA>*

CUDA (Compute Unified Device Architecture) is a proprietary parallel computing platform and application programming interface (API) developed by the American technology corporation Nvidia that allows software to use certain types of graphics processing units (GPUs) for accelerated general-purpose processing, significantly broadening their utility in scientific and high-performance computing. CUDA was created by Nvidia starting in 2004 and was officially released in 2007. When it was first introduced, the name was an acronym for Compute Unified Device Architecture, but Nvidia later dropped the common use of the acronym and now rarely expands it.
CUDA is both a software layer that manages data, giving direct access to the GPU and CPU as necessary, and a library of APIs that enable parallel computation for various needs. In addition to drivers and runtime kernels, the CUDA platform includes compilers, libraries and developer tools to help programmers accelerate their applications.
CUDA is written in the C programming language but is designed to work with a wide array of other programming languages including C++, Fortran, Python and Julia. This accessibility makes it easier for specialists in parallel programming to use GPU resources, in contrast to prior APIs like Direct3D and OpenGL, which require advanced skills in graphics programming. CUDA-powered GPUs also support programming frameworks such as OpenMP, OpenACC and OpenCL.

##  Background 
The graphics processing unit (GPU), as a specialized computer processor, addresses the demands of real-time high-resolution 3D graphics compute-intensive tasks. By 2012, GPUs had evolved into highly parallel multi-core systems allowing efficient manipulation of large blocks of data. This design is more effective than general-purpose central processing unit (CPUs) for algorithms in situations where processing large blocks of data is done in parallel, such as:

cryptographic hash functions
machine learning
molecular dynamics simulations
physics engines
The origins of CUDA trace to the early 2000s, when Ian Buck, a computer science Ph.D. student at Stanford University, began experimenting with using GPUs for purposes beyond rendering graphics. Buck had first become interested in GPUs during his undergraduate studies at Princeton University, initially through video gaming. After graduation, he interned at Nvidia, gaining deeper exposure to GPU architecture. At Stanford, he built an 8K gaming rig using 32 GeForce graphics cards, originally to push the limits of graphics performance in games like Quake and Doom. However, his interests shifted toward exploring the potential of GPUs for general-purpose parallel computing.
To that end, Buck developed Brook, a programming language designed to enable general-purpose computing on GPUs. His work attracted support from both Nvidia and the Defense Advanced Research Projects Agency (DARPA). In 2004, Nvidia hired Buck and paired him with John Nickolls, the company's director of architecture for GPU computing. Together, they began transforming Brook into what would become CUDA. CUDA was officially released by Nvidia in 2007.
Under the leadership of Nvidia CEO Jensen Huang, CUDA became central to the company's strategy of positioning GPUs as versatile hardware for scientific applications. By 2015, CUDA's development increasingly focused on accelerating machine learning and artificial neural network workloads.

##  Ontology 
The following table offers a non-exact description for the ontology of the CUDA framework.

##  Programming abilities 
The CUDA platform is accessible to software developers through CUDA-accelerated libraries, compiler directives such as OpenACC, and extensions to industry-standard programming languages including C, C++, Fortran and Python. C/C++ programmers can use 'CUDA C/C++', compiled to PTX with nvcc (Nvidia's LLVM-based C/C++ compiler) or by clang itself. Fortran programmers can use 'CUDA Fortran', compiled with the PGI CUDA Fortran compiler from The Portland Group. Python programmers can use the cuPyNumeric library to accelerate applications on Nvidia GPUs.
In addition to libraries, compiler directives, CUDA C/C++ and CUDA Fortran, the CUDA platform supports other computational interfaces, including the Khronos Group's OpenCL, Microsoft's DirectCompute, OpenGL Compute Shader and C++ AMP. Third party wrappers are also available for Python, Perl, Fortran, Java, Ruby, Lua, Common Lisp, Haskell, R, MATLAB, IDL, Julia, and native support in Mathematica.
In the computer game industry, GPUs are used for graphics rendering, and for game physics calculations (physical effects such as debris, smoke, fire, fluids); examples include PhysX and Bullet. CUDA has also been used to accelerate non-graphical applications in computational biology, cryptography and other fields by an order of magnitude or more.
CUDA provides both a low level API (CUDA Driver API, non single-source) and a higher level API (CUDA Runtime API, single-source). The initial CUDA SDK was made public on 15 February 2007, for Microsoft Windows and Linux. Mac OS X support was later added in version 2.0, which supersedes the beta released February 14, 2008. CUDA works with all Nvidia GPUs from the G8x series onwards, including GeForce, Quadro and the Tesla line. CUDA is compatible with most standard operating systems.
CUDA 8.0 comes with the following libraries (for compilation & runtime, in alphabetical order):

cuBLAS – CUDA Basic Linear Algebra Subroutines library
CUDART – CUDA Runtime library
cuFFT – CUDA Fast Fourier Transform library
cuRAND – CUDA Random Number Generation library
cuSOLVER – CUDA based collection of dense and sparse direct solvers
cuSPARSE – CUDA Sparse Matrix library
NPP – NVIDIA Performance Primitives library
nvGRAPH – NVIDIA Graph Analytics library
NVML – NVIDIA Management Library
NVRTC – NVIDIA Runtime Compilation library for CUDA C++
CUDA 8.0 comes with these other software components:

nView – NVIDIA nView Desktop Management Software
NVWMI – NVIDIA Enterprise Management Toolkit
GameWorks PhysX – is a multi-platform game physics engine
CUDA 9.0–9.2 comes with these other components:

CUTLASS 1.0 – custom linear algebra algorithms,
NVIDIA Video Decoder was deprecated in CUDA 9.2; it is now available in NVIDIA Video Codec SDK
CUDA 10 comes with these other components:

nvJPEG – Hybrid (CPU and GPU) JPEG processing
CUDA 11.0–11.8 comes with these other components:

CUB is new one of more supported C++ libraries
MIG multi instance GPU support
nvJPEG2000 – JPEG 2000 encoder and decoder

##  Advantages 
CUDA has several advantages over traditional general-purpose computation on GPUs (GPGPU) using graphics APIs:

Scattered reads – code can read from arbitrary addresses in memory
Unified virtual memory (CUDA 4.0 and above)
Unified memory (CUDA 6.0 and above)
Shared memory – CUDA exposes a fast shared memory region that can be shared among threads. This can be used as a user-managed cache, enabling higher bandwidth than is possible using texture lookups.
Faster downloads and readbacks to and from the GPU
Full support for integer and bitwise operations, including integer texture lookups

##  Limitations 
Whether for the host computer or the GPU device, all CUDA source code is now processed according to C++ syntax rules. This was not always the case. Earlier versions of CUDA were based on C syntax rules. As with the more general case of compiling C code with a C++ compiler, it is therefore possible that old C-style CUDA source code will either fail to compile or will not behave as originally intended.
Interoperability with rendering languages such as OpenGL is one-way, with OpenGL having access to registered CUDA memory but CUDA not having access to OpenGL memory.
Copying between host and device memory may incur a performance hit due to system bus bandwidth and latency (this can be partly alleviated with asynchronous memory transfers, handled by the GPU's DMA engine).
Threads should be running in groups of at least 32 for best performance, with total number of threads numbering in the thousands. Branches in the program code do not affect performance significantly, provided that each of 32 threads takes the same execution path; the SIMD execution model becomes a significant limitation for any inherently divergent task (e.g. traversing a space partitioning data structure during ray tracing).
No emulation or fallback functionality is available for modern revisions.
Valid C++ may sometimes be flagged and prevent compilation due to the way the compiler approaches optimization for target GPU device limitations.
C++ run-time type information (RTTI) and C++-style exception handling are only supported in host code, not in device code.
In single-precision on first generation CUDA compute capability 1.x devices, denormal numbers are unsupported and are instead flushed to zero, and the precision of both the division and square root operations are slightly lower than IEEE 754-compliant single precision math. Devices that support compute capability 2.0 and above support denormal numbers, and the division and square root operations are IEEE 754 compliant by default. However, users can obtain the prior faster gaming-grade math of compute capability 1.x devices if desired by setting compiler flags to disable accurate divisions and accurate square roots, and enable flushing denormal numbers to zero.
Unlike OpenCL, CUDA-enabled GPUs are only available from Nvidia as it is proprietary. Attempts to implement CUDA on other GPUs include:
Project Coriander: Converts CUDA C++11 source to OpenCL 1.2 C. A fork of CUDA-on-CL intended to run TensorFlow.
CU2CL: Convert CUDA 3.2 C++ to OpenCL C.
GPUOpen HIP: A thin abstraction layer on top of CUDA and ROCm intended for AMD and Nvidia GPUs. Has a conversion tool for importing CUDA C++ source. Supports CUDA 4.0 plus C++11 and float16.
ZLUDA is a drop-in replacement for CUDA on AMD GPUs and formerly Intel GPUs with near-native performance. The developer, Andrzej Janik, was separately contracted by both Intel and AMD to develop the software in 2021 and 2022, respectively. However, neither company decided to release it officially due to the lack of a business use case. AMD's contract included a clause that allowed Janik to release his code for AMD independently, allowing him to release the new version that only supports AMD GPUs.
ChipStar can compile and run CUDA/HIP programs on advanced OpenCL 3.0 or Level Zero platforms.
SCALE is a CUDA-compatible programming toolkit for ahead of time compilation of CUDA source code on AMD GPUs, aiming to expand support for other GPUs in the future.

##  Example 
This example code in C++ loads a texture from an image into an array on the GPU:

Below is an example given in Python that computes the product of two arrays on the GPU. The unofficial Python language bindings can be obtained from PyCUDA.

Additional Python bindings to simplify matrix multiplication operations can be found in the program pycublas.

while CuPy directly replaces NumPy:

##  GPUs supported 
Note on notation: compute capability X.Y is also written as SMXY or sm_XY (e.g. 10.3 as SM103 or sm_103) in professional Nvidia software and the code Nvidia has contributed to LLVM.
Below is a table of supported CUDA compute capabilities based on the CUDA SDK version and microarchitecture, listed by code name:

Note: CUDA SDK 10.2 is the last official release for macOS, as support will not be available for macOS in newer releases.
CUDA compute capability by version with associated GPU semiconductors and GPU card models (separated by their various application areas):

* – OEM-only products

##  Version features and specifications 
Note: A GPU with a higher compute capacity is able to execute PTX code meant for a GPU of a lower range of compute capacities. However, it is possible to compile CUDA code into a form that only works on one family (same "X") of GPUs; if existing code is compiled this way, recompilation will be needed for it to work on a newer GPU.

###  Data types 
####  Floating-point types 
####  Version support 
Note: Any missing lines or empty entries do reflect some lack of information on that exact item.

###  Tensor cores 
Note: Any missing lines or empty entries do reflect some lack of information on that exact item.

###  Technical specifications 
###  Multiprocessor architecture 
For more information read the Nvidia CUDA C++ Programming Guide.

##  Usages of CUDA architecture 
Accelerated rendering of 3D graphics
Accelerated interconversion of video file formats
Accelerated encryption, decryption and compression
Bioinformatics, e.g. NGS DNA sequencing BarraCUDA
Distributed calculations, such as predicting the native conformation of proteins
Medical analysis simulations, for example virtual reality based on CT and MRI scan images
Physical simulations, particularly in fluid dynamics
Neural network training in machine learning problems
Large Language Model inference
Face recognition
Volunteer computing projects, such as SETI@home and other projects using BOINC software
Molecular dynamics
Mining cryptocurrencies
Structure from motion (SfM) software

##  Comparison with competitors 
CUDA competes with other GPU computing stacks: Intel OneAPI and AMD ROCm.
Whereas Nvidia's CUDA is closed-source, Intel's OneAPI and AMD's ROCm are open source.

###  Intel OneAPI 
oneAPI is an initiative based in open standards, created to support software development for multiple hardware architectures. The oneAPI libraries must implement open specifications that are discussed publicly by the Special Interest Groups, offering the possibility for any developer or organization to implement their own versions of oneAPI libraries.
Originally made by Intel, other hardware adopters include Fujitsu and Huawei.

####  Unified Acceleration Foundation (UXL) 
Unified Acceleration Foundation (UXL) is a new technology consortium working on the continuation of the OneAPI initiative, with the goal to create a new open standard accelerator software ecosystem, related open standards and specification projects through Working Groups and Special Interest Groups (SIGs). The goal is to offer open alternatives to Nvidia's CUDA. The main companies behind it are Intel, Google, ARM, Qualcomm, Samsung, Imagination, and VMware.

###  AMD ROCm 
ROCm is an open source software stack for graphics processing unit (GPU) programming from Advanced Micro Devices (AMD).

##  See also 
Array programming
BrookGPU – the Stanford University graphics group's compiler
CUDA binary (cubin) – a type of fat binary
Molecular modeling on GPUs
Numerical Library Collection – by NEC for their vector processor
OptiX – ray tracing API by NVIDIA
Parallel computing
rCUDA – an API for computing on remote computers
Stream processing
SYCL – an open standard from Khronos Group for programming a variety of platforms, including GPUs, with single-source modern C++, similar to higher-level CUDA Runtime API (single-source)
Vulkan – low-level, high-performance 3D graphics and computing API

##  References 
##  Further reading 
Buck, Ian; Foley, Tim; Horn, Daniel; Sugerman, Jeremy; Fatahalian, Kayvon; Houston, Mike; Hanrahan, Pat (2004-08-01). "Brook for GPUs: stream computing on graphics hardware". ACM Transactions on Graphics. 23 (3): 777–786. doi:10.1145/1015706.1015800. ISSN 0730-0301.
Nickolls, John; Buck, Ian; Garland, Michael; Skadron, Kevin (2008-03-01). "Scalable Parallel Programming with CUDA: Is CUDA the parallel programming model that application developers have been waiting for?". ACM Queue. 6 (2): 40–53. doi:10.1145/1365490.1365500. ISSN 1542-7730.

##  External links 
Official website 
CUDA textbooks
