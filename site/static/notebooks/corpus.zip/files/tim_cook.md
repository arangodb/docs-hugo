# Tim Cook

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/Tim_Cook>*

Timothy Donald Cook (born November 1, 1960) is an American business executive who has served as the chief executive officer (CEO) of Apple since 2011. He had previously been the company's chief operating officer under its co-founder Steve Jobs. Cook joined Apple in March 1998 as a senior vice president for worldwide operations, and then as vice president for worldwide sales and operations. He was appointed chief executive of Apple on August 24, 2011, after Jobs resigned.
During his tenure as the chief executive of Apple and while serving on its board of directors, he has advocated for the political reform of international and domestic surveillance, cybersecurity, national manufacturing, and environmental preservation. Since becoming CEO, Cook has also replaced Jobs' micromanagement with a more liberal style and implemented a collaborative culture at Apple.
Between 2011, when he took over Apple, and 2020, Cook doubled the company's revenue and profit, and the company's market value increased from $348 billion to $1.9 trillion. In 2025, Apple was the second largest technology company by revenue, with US$416 billion.
Outside of Apple, Cook has sat on the board of directors of Nike since 2005. He also sits on the board of the National Football Foundation and is a trustee of Duke University, his alma mater. Cook engages in philanthropy; in March 2015 he said he planned to donate his fortune to charity. In 2014, Cook became the first and only chief executive of a Fortune 500 company to publicly come out as gay. In October 2014, the Alabama Academy of Honor inducted Cook, who spoke on the state's record of LGBTQ rights. It is the highest honor Alabama gives its citizens. In 2012 and 2021, Cook appeared on the Time 100, Time's annual list of the 100 most influential people in the world. As of December 2025, his net worth is estimated at $2.6 billion, according to Forbes.
In April 2026, Apple announced that Cook would be stepping down as CEO of Apple on September 1, 2026. John Ternus was named as successor.

##  Early life and education 
Timothy Donald Cook was born on November 1, 1960, in the city of Mobile, Alabama. He was baptized in a Baptist church and grew up in the nearby city Robertsdale. His father, Donald Cook, was a shipyard worker. His mother, Geraldine Cook, worked at a pharmacy. Cook graduated salutatorian from the public Robertsdale High School in Alabama in 1978.
Cook received a Bachelor of Science with a major in industrial engineering from Auburn University in 1982 and a Master of Business Administration from Duke University in 1988.

##  Career 
###  Pre-Apple era 
After graduating from Auburn University, Cook spent twelve years in IBM's personal computer business, ultimately as director of North American fulfillment. During this time, Cook also earned his MBA from Duke University, becoming a Fuqua Scholar in 1988. Later, he was the chief operating officer of the computer reseller division of Intelligent Electronics. In 1997, he became the vice president for corporate materials at Compaq, but took up his position at Apple six months later.

###  Apple era 
####  Early career 
In 1998, Steve Jobs asked Cook to join Apple. In a 2010 commencement speech at Auburn University, Cook said he decided to join Apple after meeting Jobs:

Any purely rational consideration of cost and benefits lined up in Compaq's favor, and the people who knew me best advised me to stay at Compaq... On that day in early 1998, I listened to my intuition, not the left side of my brain or for that matter even the people who knew me best... no more than five minutes into my initial interview with Steve, I wanted to throw caution and logic to the wind and join Apple. My intuition already knew that joining Apple was a once-in-a-lifetime opportunity to work for the creative genius and to be on the executive team that could resurrect a great American company.
His first position was senior vice president for worldwide operations. Cook closed factories and warehouses, and replaced them with contract manufacturers; this resulted in a reduction of the company's inventory from months to days. Predicting its importance, his group had invested in long-term deals such as advance investment in flash memory since 2005. This guaranteed a stable supply of what became the iPod Nano, then iPhone and iPad. Competitors at Hewlett-Packard described their cancelled HP TouchPad tablet computer and later said that it was made from "cast-off, reject iPad parts". Cook's actions were recognized for keeping costs under control, and combined with the rest of the company, generated huge profits.
In January 2007, Cook was promoted to lead operations and was chief executive in 2009, while Jobs, in failing health, was away on a leave of absence. In January 2011, Apple's board of directors approved a third medical leave of absence requested by Jobs. During that time, Cook was responsible for most of Apple's day-to-day operations, while Jobs made most major decisions.

####  Apple chief executive 
After Jobs resigned as CEO and became chairman of the board, Cook was named the new chief executive officer of Apple on August 24, 2011. Six weeks later, on October 5, 2011, Jobs died due to complications from pancreatic cancer. Forbes contributor Robin Ferracone wrote in September 2011: "Jobs and Cook proceeded to forge a strong partnership, and rescued the company from its death spiral, which took it from $11 billion in revenue in 1995 down to less than $6 billion in 1998 ... Under their leadership, the company went from its nadir to a remarkable $100 billion today".

On October 29, 2012, Cook made major changes to the company's executive team. Scott Forstall resigned as senior vice president of iOS after the poorly received launch of Apple Maps, and became an advisor to Cook until he eventually departed from the company in 2013. John Browett, who was senior VP of retail, was dismissed six months after he commenced at Apple, and given 100,000 shares worth US$60 million. Forstall's duties were divided among four other Apple executives: design SVP Jony Ive assumed leadership of Apple's human interface team; Craig Federighi became the new head of iOS software engineering; services chief Eddy Cue became responsible for Maps and Siri; and Bob Mansfield, previously SVP of hardware engineering, became the head of a new technology group.
Cook made the executive changes after the third quarter of fiscal year 2012, when revenues and profits grew less than predicted. Forstall's resignation was widely seen as a dismissal, allegedly caused by Cook's desire to reduce "rivalries between executives", and drew criticism, as Forstall had been seen as a possible successor to Cook. 
In May 2013 Cook shared that his leadership focused on people, strategy, and execution; he explained, "If you get those three right the world is a great place." Under Cook's leadership, Apple increased its donations to charity, and in 2013 he hired Lisa Jackson, formerly the head of the Environmental Protection Agency, to assist Apple with the development of its renewable energy activities.

In 2016, some analysts compared Cook to former Microsoft CEO Steve Ballmer, claiming that innovation had died down since he replaced Jobs, similar to when Ballmer became Microsoft CEO in 2000.
As CEO of Apple, Cook met U.S. House members on December 10, 2025 to push back against a federal legislation that could require Apple to authenticate users' ages and possibly collect sensitive data on children.
In August 2021, Cook received an approximate $750 million payout, selling more than five million shares in Apple, ten years after becoming CEO.
Apple announced on April 20, 2026, that Cook will step down as CEO on September 1, 2026, and will take the role of Executive Chairman. This initiative was decided from a multi-year succession plan from Apple. John Ternus, currently Apple's Senior Vice President of hardware engineering, will then take over as CEO.

##  Political positions and affiliations 
During the 2008 election cycle, Cook donated to Barack Obama's first White House election. 
On February 28, 2014, Cook made headlines when he challenged shareholders to "get out of the stock" if they did not share the company's views on sustainability and climate change.
In 2015, Cook said he donated to Democratic senators Chuck Schumer and Patrick Leahy for their stances on ebook pricing and surveillance reform, respectively. During the same election cycle, he hosted a fundraiser for Republican senator Rob Portman. In early March 2016, Cook disclosed that he donated to the election campaign of Democratic representative Zoe Lofgren of California. In early June, Cook hosted a private fundraiser along with then speaker of the U.S. House of Representatives Paul Ryan. The event was described by Politico as "a joint fundraising committee aimed at helping to elect other House Republicans."

In the 2016 election, Cook raised funds for the presidential campaign of Hillary Clinton. At one point, Clinton's campaign considered Cook as a candidate for Vice President. In September 2017 at Bloomberg's Global Business Forum, Cook defended the DACA immigration program. He expressed his dissatisfaction with the direction of Donald Trump's administration, stating: "This is unacceptable. This is not who we are as a country. I am personally shocked that there is even a discussion of this."

In 2018, at a privacy conference in Brussels, Cook expressed his opinions on the stockpiling of personal data by tech firms, suggesting that it amounted to surveillance and should make the public "very uncomfortable."

###  Relationship with China 
In May 2016, Cook traveled to China to meet with government officials there after the Chinese government closed Apple's online iTunes Store and Apple Books store. In December 2017, Cook was a speaker at the World Internet Conference in China. Cook was appointed chairman of the advisory board for Tsinghua University's economics school in October 2019 for a three-year term.
Several lawmakers criticized Cook in 2019 over Apple's decision to remove an app used by pro-democracy protesters in Hong Kong from its App Store. They accused Apple of censorship, and co-signed a letter to Cook that read, "Apple's decisions last week to accommodate the Chinese government by taking down HKMaps is deeply concerning. We urge you in the strongest terms to reverse course, to demonstrate that Apple puts values above market access, and to stand with the brave men and women fighting for basic rights and dignity in Hong Kong." Cook explained in an internal letter why the company removed the Hong Kong mapping app used by protesters to coordinate movements.
In 2016, Cook signed a $275 billion deal with Chinese officials. The deal – personally negotiated by Cook – paved the way for increased censorship by Apple in China, for example the removal of Muslim content, preventing users from entering numbers that refer to the date of the Tiananmen Square Massacre, censoring Chinese words like "human rights" or "democracy", and manipulating Apple Maps to support China in the Senkaku Islands dispute by making Chinese-claimed islands appear larger than they actually were. 

###  Relationship with Donald Trump 
In a meeting for the American Workforce Policy Advisory Board with President Donald Trump in March 2019, Trump referred to Cook as "Tim Apple", leading to widespread jokes on social media. Cook acknowledged the event by changing his display name on Twitter to "Tim ", using the Private Use Areas character  which renders as the Apple logo on Apple devices.
In January 2025, Cook personally donated $1 million to Donald Trump's inaugural committee. On January 20, 2025, Cook attended the second inauguration of Donald Trump inside the rotunda of the U.S. Capitol. Other billionaires were also there including Elon Musk, Mark Zuckerberg, and Jeff Bezos.
On August 6, 2025, Cook visited Donald Trump at the White House, presenting him with a glass plaque set in a 24-karat gold base made from American materials. Cook announced an additional $100 billion in U.S. investments, bringing Apple's total commitment to $600 billion, as part of the company's strategy to align with Trump's "America First" policies and avoid potential tariffs on semiconductors.

Cook joined Trump on his trip to China in May 2026.

##  Personal life 
Cook is a fitness enthusiast and enjoys hiking, cycling, and going to the gym. He is known for being solitary, using an off-campus fitness center for privacy, and little is publicly shared about his personal life. He explained in October 2014 that he has sought to achieve a "basic level of privacy". Cook was misdiagnosed with multiple sclerosis in 1996, an incident he said made him "see the world in a different way". He has since taken part in charity fundraising, such as cycle races to raise money for the disease. He later told the Auburn alumni magazine that his symptoms came from "lugging a lot of incredibly heavy luggage around".
Cook has said that in 2009 he offered a portion of his liver to Jobs, as they shared a rare blood type. Cook said that Jobs responded by yelling, "I'll never let you do that. I'll never do that." While delivering the 2010 commencement speech at Auburn, Cook emphasized the importance of intuition during significant decision-making processes, and explained that preparation and hard work are also necessary to execute on intuition. In 2015, Cook was named to Duke University's board of trustees for a six-year term. He later delivered the university's commencement address in 2018.
In June 2014, Cook attended San Francisco's gay pride parade along with a delegation of Apple staff. A few months later, Cook publicly came out as gay in an editorial for Bloomberg Business, saying, "I'm proud to be gay, and I consider being gay among the greatest gifts God has given me." It had been reported in early 2011 that Cook was gay, but Cook tried to keep his personal life private. He did publicly support LGBTQ rights. He consulted with Anderson Cooper, who had publicly come out himself, on aspects of the statement, and cleared the timing to ensure it would not distract from business interests. Cook had been open about his sexuality "for years", and though many people at the company were aware of his sexual orientation, he sought to focus on Apple's products and customers rather than his personal life. He ended his op-ed by writing, "We pave the sunlit path toward justice together, brick by brick. This is my brick."
In September 2015, Cook clarified on The Late Show with Stephen Colbert, "Where I valued my privacy significantly, I felt that I was valuing it too far above what I could do for other people, so I wanted to tell everyone my truth." In October 2019, he talked about the decision and remarked on how it was thanks to LGBTQ people who had fought for their rights before him that paved the way for his success, and that he needed to let younger generations know that, in a coding analogy, he saw being gay as a feature his life had to offer rather than any problem. He hoped his openness could give LGBTQ youth dealing with homelessness and suicide a sense of hope that their situation can improve.

##  Awards and honors 
Financial Times Person of the Year (2014)
Ripple of Change Award (2015)
Fortune's World's Greatest Leader (2015)
Alabama Academy of Honor: Inductee (2015)
Human Rights Campaign's Visibility Award (2015)
Honorary Doctor of Science from University of Glasgow in Glasgow, Scotland (2017)
Courage Against Hate award from Anti-Defamation League (2018)
Honorary Master’s degree in Innovation and International Management from University of Naples Federico II in Naples, Italy (2022)
National Academy of Engineering: Inductee (2026)

##  References 
##  Further reading 
Matt Richtel, Brian X. Chen (15 June 2015). "Tim Cook, Making Apple His Own". The New York Times.

##  External links 
Tim Cook on X 
Apple profile
Forbes profile
