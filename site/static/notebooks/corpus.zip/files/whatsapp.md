# WhatsApp

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/WhatsApp>*

WhatsApp Messenger, commonly known simply as WhatsApp, is an American social media, instant messaging (IM), and Voice over IP (VoIP) service accessible via desktop and mobile app. Owned by Meta Platforms, the service allows users to send text messages, voice messages, and video messages, make voice and video calls, and share images, documents, user locations, and other content. The service requires a cellular mobile telephone number to register. WhatsApp was launched in May 2009. In January 2018, WhatsApp released a standalone business app called WhatsApp Business which can communicate with the standard WhatsApp client. As of May 2025, the service had 3 billion monthly active users, making it the most popular messenger app. The name of the app is meant to sound like "what's up".
The service was created by WhatsApp Inc. of Mountain View, California, which was acquired by Facebook in February 2014 for approximately US$19.3 billion. It became the world's most popular messaging application in 2015, with 900 million users, and had more than 2 billion active users worldwide in February 2020. WhatsApp Business had approximately 200 million monthly users in 2023. By 2016, it had become the primary means of Internet communication in regions including the Americas, the Indian subcontinent, and large parts of Europe and Africa.

##  History 
###  2009–2014 
WhatsApp was founded by Brian Acton and Jan Koum, former employees of Yahoo. Koum incorporated WhatsApp Inc. in California on February 24, 2009. A month earlier, Koum had purchased an iPhone, and he and Acton decided to create an app for the App Store. The idea started off as an app that would display statuses in a phone's Contacts menu, showing if a person was at work or on a call.
Their discussions often took place at the home of Koum's Russian friend Alex Fishman in West San Jose. They realized that to take the idea further, they would need an iPhone developer. Fishman visited RentACoder.com, found Russian developer Igor Solomennikov, and introduced him to Koum.
Koum named the app WhatsApp to sound like "what's up" and it was published on the Apple App Store and BlackBerry App World in May and June 2009 respectively. However, when early versions of WhatsApp kept crashing, Koum considered giving up and looking for a new job. Acton encouraged him to wait for a "few more months".
In June 2009, when the app had been downloaded by only a handful of Fishman's Russian-speaking friends, Apple launched push technology, allowing users to be pinged even when not using the app. Koum updated WhatsApp so that everyone in the user's network would be notified when a user's status changed. This new facility, to Koum's surprise, was used by users to ping "each other with jokey custom statuses like, 'I woke up late' or 'I'm on my way.'" Fishman said, "At some point it sort of became instant messaging".
WhatsApp 2.0, released for iPhone in August 2009, featured a purpose-designed messaging component; the number of active users suddenly increased to 250,000.
Although Acton was working on another startup idea, he decided to join the company. In October 2009, Acton persuaded five former friends at Yahoo! to invest $250,000 in seed funding, and Acton became a co-founder and was given a stake. He officially joined WhatsApp on November 1. Koum then hired a friend in Los Angeles, Chris Peiffer, to develop a BlackBerry version, which arrived two months later. Subsequently, WhatsApp for Symbian OS was added in May 2010, and for Android OS in August 2010. In 2010 Google made multiple acquisition offers for WhatsApp, which were all declined.
To cover the cost of sending verification texts to users, WhatsApp was changed from a free service to a paid one. In December 2009, the ability to send photos was added to the iOS version. By early 2011, WhatsApp was one of the top 20 apps in the U.S. Apple App Store.
In April 2011, Sequoia Capital invested about $8 million for more than 15% of the company, after months of negotiation by Sequoia partner Jim Goetz.
By February 2013, WhatsApp had about 200 million active users and 50 staff members. Sequoia invested another $50 million at a $1.5 billion valuation. Some time in 2013 WhatsApp acquired Santa Clara–based startup SkyMobius, the developers of Vtok, a video and voice calling app.
As of December 2013, the service had 400 million monthly active users. That year, the company had $148 million in expenses and a net loss of $138 million.

###  2014–2015 
On February 19, 2014, one year after the venture capital financing round at a $1.5 billion valuation, Facebook, Inc. (now Meta Platforms) agreed to acquire the company for US$19 billion, its largest acquisition to date. At the time, it was the largest acquisition of a venture-capital-backed company in history. Sequoia Capital received an approximate 5,000% return on its initial investment. Facebook paid $4 billion in cash, $12 billion in Facebook shares, and an additional $3 billion in restricted stock units granted to WhatsApp's founders Koum and Acton. Employee stock was scheduled to vest over four years subsequent to closing. Days after the announcement, WhatsApp users experienced a loss of service, leading to anger across social media.
The acquisition was influenced by the data provided by Onavo, Facebook's research app for monitoring competitors and trending usage of social activities on mobile phones, as well as startups that were performing "unusually well".
The acquisition caused many users to try, or move to, other message services. Telegram claimed that it acquired 8 million new users, and Line, 2 million.

At a keynote presentation at the Mobile World Congress in Barcelona in February 2014, Facebook CEO Mark Zuckerberg said that Facebook's acquisition of WhatsApp was closely related to the Internet.org vision. A TechCrunch article said about Zuckerberg's vision:The idea, he said, is to develop a group of basic internet services that would be free of charge to use – "a 911 for the internet". These could be a social networking service like Facebook, a messaging service, maybe search and other things like weather. Providing a bundle of these free of charge to users will work like a gateway drug of sorts – users who may be able to afford data services and phones these days just don't see the point of why they would pay for those data services. This would give them some context for why they are important, and that will lead them to pay for more services like this – or so the hope goes.
Three days after announcing the Facebook purchase, Koum said they were working to introduce voice calls. He also said that new mobile phones would be sold in Germany with the WhatsApp brand, and that their ultimate goal was to be on all smartphones.
In August 2014, WhatsApp was the most popular messaging app in the world, with more than 600 million users. By early January 2015, WhatsApp had 700 million monthly users and over 30 billion messages every day. In April 2015, Forbes predicted that between 2012 and 2018, the telecommunications industry would lose $386 billion because of "over-the-top" services like WhatsApp and Skype. That month, WhatsApp had over 800 million users. By September 2015, it had grown to 900 million; and by February 2016, one billion.
On November 30, 2015, the Android WhatsApp client made links to Telegram unclickable and not copyable. Multiple sources confirmed that it was intentional, not a bug, and that it had been implemented when the Android source code that recognized Telegram URLs had been identified. (The word "telegram" appeared in WhatsApp's code.) Some considered it an anti-competitive measure; WhatsApp offered no explanation.

###  2016–2019 
On January 18, 2016, WhatsApp's co-founder Jan Koum announced that it would no longer charge users a $1 annual subscription fee, in an effort to remove a barrier faced by users without payment cards. He also said that the app would not display any third-party ads, and that it would have new features such as the ability to communicate with businesses.
On May 18, 2017, the European Commission announced that it was fining Facebook €110 million for "providing misleading information about WhatsApp takeover" in 2014. The Commission said that in 2014 when Facebook acquired the messaging app, it "falsely claimed it was technically impossible to automatically combine user information from Facebook and WhatsApp." However, in the summer of 2016, WhatsApp had begun sharing user information with its parent company, allowing information such as phone numbers to be used for targeted Facebook advertisements. Facebook acknowledged the breach, but said the errors in their 2014 filings were "not intentional".
In September 2017, WhatsApp's co-founder Brian Acton left the company to start a nonprofit group, later revealed as the Signal Foundation, which developed the WhatsApp competitor Signal. He explained his reasons for leaving in an interview with Forbes a year later. WhatsApp also announced a forthcoming business platform to enable companies to provide customer service at scale, and airlines KLM and Aeroméxico announced their participation in the testing. Both airlines had previously launched customer services on the Facebook Messenger platform.
In January 2018, WhatsApp launched WhatsApp Business for small business use.
In April 2018, WhatsApp co-founder and CEO Jan Koum announced he would be leaving the company. By leaving before November 2018, due to concerns about privacy, advertising, and monetization by Facebook, Acton and Koum were initially believed to have given up $1.3 billion in unvested stock options, however, it was later reported that Koum retained $450M worth of options via a "rest and vest" program. Facebook later announced that Koum's replacement would be Chris Daniels.
On November 25, 2019, WhatsApp announced an investment of $250,000 through a partnership with Startup India to provide 500 startups with Facebook ad credits of $500 each.
In December 2019, WhatsApp announced that a new update would lock out any Apple users who had not updated to iOS 9 or higher and Samsung, Huawei, Sony and Google users who had not updated to version 4.0 by February 1, 2020. The company also reported that Windows Phone operating systems would no longer be supported after December 31, 2019. WhatsApp was announced to be the 3rd most downloaded mobile phone app of the decade 2010–2019.

###  Since 2020 
In March 2020, WhatsApp partnered with the World Health Organization and UNICEF to provide messaging hotlines for people to get information on the COVID-19 pandemic. In the same month, WhatsApp began testing a feature to help users find out more information and context about information they receive to help combat misinformation.
In January 2021, WhatsApp announced a controversial new privacy policy allowing WhatsApp to share data with its parent company, Facebook. This led many users to delete WhatsApp and instead use services such as Signal and Telegram. However, the WhatsApp privacy policy does not apply in the EU, since it violates the principles of GDPR. Facing criticism, WhatsApp postponed the update to May 15, 2021, and had no plans to limit functionality of users, nor nag users who did not approve the new terms.
The 2021 Facebook outage affected other platforms owned by Facebook, such as Instagram and WhatsApp.
In May 2022, WhatsApp launched its Cloud API services (now known as WhatsApp Business Platform) for larger businesses requiring features beyond the WhatsApp Business App. The Cloud API enables businesses to integrate WhatsApp with other software, have a central WhatsApp account for multiple users and implement advanced automation.
In August 2022, WhatsApp launched an integration with JioMart, available only to users in India. Local users can text special numbers in the app to launch an in-app shopping process, where they can order groceries.
In March 2024, Meta announced that WhatsApp would let third-party messaging services enable interoperability with WhatsApp, a requirement of the EU's Digital Markets Act (DMA). This allows users to send messages between other messaging apps and WhatsApp while maintaining end-to-end encryption.
In January 2026, WhatsApp placed third in YouGov's Best Brands Rankings 2026 report.
In March 2026, Meta allowed AI rivals to be allowed on WhatsApp for a year, in a bid to prevent a possible temporary order from EU antitrust regulators after complains from competitors who were blocked from WhatsApp.
In April 2026, WhatsApp began testing WhatsApp Plus, an optional subscription to the service that unlocks cosmetic and organizational features, such as unique chat themes, custom lists and more pinned chats. The subscription launched on May 27, 2026.
On June 22, 2026, WhatsApp appointed Kunal Shah as its new head.
In June 2026, WhatsApp began rolling out username reservations for its more than 3 billion users ahead of the public launch of usernames, allowing users to reserve unique usernames before the feature became generally available.

##  Features 
###  Presence 
On February 24, 2017, WhatsApp launched a new Status feature similar to Snapchat and Facebook stories. WhatsApp has rolled out a feature called 'Voice Status Updates', which allows users to record voice notes and share them as their status on the app.
WhatsApp has the facility to hide users' online status ("Last Seen"). In December 2021, WhatsApp changed the default setting from "everyone" to only people in the user's contacts or who have been conversed with ("nobody" is also an option). In 2022, WhatsApp added the ability for users to turn off their online status.

###  General texting 
In October 2018, the "Swipe to Reply" option was added to the Android beta version, 16 months after it was introduced for iOS.
In early 2020, WhatsApp launched its "dark mode" for iPhone and Android devices – a new design consisting of a darker palette.
In October 2020, WhatsApp rolled out a feature allowing users to mute both individuals and group chats forever. The mute options are "8 hours", "1 week", and "Always". The "Always" option replaced the "1 year" option that was originally part of the settings.
In May 2023, WhatsApp allowed users to edit messages, aligning itself with competitors such as Telegram and Signal which already offered this feature. According to the company, messages could be edited within a 15-minute window after being sent. Edited messages were tagged as "edited" to inform recipients that the content had been modified. Text formatting options like code blocks, quote blocks, and bulleted lists also became available for the first time.
In October 2024, WhatsApp expanded their chat filter feature, adding the ability for users to create custom lists that contain specific chats of their choice.

###  Voice and video calling and notes 
In August 2013, WhatsApp added voice messages to their apps, giving users a way to send short audio recordings directly in their chats.
Voice calls between two accounts were added to the app in March and April 2015. By June 2016, the company's blog reported more than 100 million voice calls per day were being placed on WhatsApp.
In November 2016, video calls between two accounts were introduced.
Later in September 2018, WhatsApp introduced group audio and video call features.
In July 2023, video messages were added to WhatsApp. Similar to voice messages, this feature allows users to record and send short videos directly in a chat. This lets users share videos of themselves more quickly, and without adding anything to their device's gallery. Currently, video messages are limited to 60 seconds.
In November 2023, WhatsApp added a "voice chat" feature for groups with more than 32 members. Unlike their 32-person group calls, starting a voice chat does not call all group members directly; they instead receive a notification to join the voice chat.
In December 2023, WhatsApp's "View Once" feature expanded to include voice messages. Voice messages sent this way are deleted after the recipient listens to them the first time.
In June 2024, improvements were made to voice and video calls, allowing up to 32 participants in video calls, adding audio to screen sharing, and introducing a new codec to increase call reliability.
In November 2024, the ability to transcribe voice messages was added, allowing users to read out what was said in a voice message, rather than listening to the audio.
In December 2024, WhatsApp introduced several new video calling features, including the ability to select specific participants from a group to make a call, rather than calling all group members. Visual effects also became available, adding visual filters to a user's video feed.

###  File sharing 
In November 2010, a slate of improvements for the iOS version of WhatsApp were released, including the ability to search for messages in your chat history, trimming long videos to a sendable size, the ability to cancel media messages as they upload or download, and previewing photos before sending them. In March 2012, WhatsApp improved its location-sharing function, allowing users to share not only their location, but also the location of places, such as restaurants or hotels.
In July 2017, WhatsApp added support for file uploads of all file types, with a limit of 100 MB. Previously between March 2016 and May 2017, only limited file types categorised as images (JPG, PNG, GIF), videos (MP4, AVI), and documents (CSV, DOC/DOCX, PDF, PPT/PPTX, RTF, TXT, XLS/XLSX), were allowed to be shared for file attachments.
In July 2021, WhatsApp announced forthcoming support for sending uncompressed images and videos in 3 options: Auto, Best Quality and Data Saver.
In May 2022, the file upload limit was raised from 100 MB to 2 GB, and the maximum group size increased to 512 members.

###  Security and encryption 
On November 10, 2016, WhatsApp launched a beta version of two-factor authentication for Android users, which allowed them to use their email addresses for further protection. Also in November 2016, Facebook ceased collecting WhatsApp data for advertising in Europe.
In October 2019, WhatsApp officially launched a new fingerprint app-locking feature for Android users.
In July 2021, WhatsApp announced forthcoming support for end-to-end encryption for backups stored in Facebook's cloud.
In August 2021, WhatsApp launched a feature that allows chat history to be transferred between mobile operating systems. This was implemented only on Samsung phones, with plans to expand to Android and iOS "soon".
In October 2023 they also introduced passkey support, where a user can verify their login with on-device biometrics, rather than SMS. In November 2023, WhatsApp also began rolling out support for sending login codes to a linked email address, rather than via SMS. In a later update on November 30, WhatsApp added a Secret Code feature, which allows those who use locked chats to enter a unique password that hides those chats from view when unlocking the app.
On 11 March 2026, WhatsApp launched parent-managed accounts for pre-teens, restricted to messaging and calling, due to safety concerns about the impact of social media and chat apps on children. These chats will remain private and protected with end-to-end encryption.

###  Linked and multi-device support 
In January 2015, WhatsApp launched a web client that allowed users to scan a QR code with their mobile app, mirroring their chats to their browser. The web client was not standalone, and required the user's phone to stay on and connected to the internet. It was also not available for iOS users on launch, due to limitations from Apple. Since then, linked devices support has expanded and more information is written in the Platform Support part of this article.
In July 2021 the company was also testing multi-device support, allowing computer users to run WhatsApp without an active phone session.
In April 2023, the app rolled out a feature that would allow account access across multiple phones, in a shift that would make it more like competitors. Messages would still be end-to-end encrypted. WhatsApp officially rolled out the Companion mode for Android users, allowing linking up to five Android phones to a single account. Now, the feature is also made available to iOS users, allowing them to link up to four iPhones.
In October 2023, support for logging in to multiple (meaning two) accounts was added, allowing users to switch between different WhatsApp accounts in the same app.

###  Stickers and avatars 
On October 25, 2018, WhatsApp announced support for Stickers. Unlike other platforms, WhatsApp requires third-party apps to add Stickers to WhatsApp.
In March 2021, WhatsApp started rolling out support for third-party animated stickers, initially in Iran, Brazil and Indonesia, then worldwide.
In December 2022, WhatsApp launched 3D digital avatars. Users are able to use an avatar as their profile picture or use it for stickers during instant messaging, similar to those offered by Bitmoji or Memoji.

###  Communities and Channels 
In April 2022, WhatsApp announced undated plans to roll out a Communities feature allowing several group chats to exist in a shared space, getting unified notifications and opening up smaller discussion groups. The company also announced plans to implement reactions, the ability for administrators to delete messages in groups and voice calls up to 32 participants.
In June 2023, a feature called WhatsApp Channels was launched which allows content creators, public figures and organizations to send newsletter-like broadcasts to large numbers of users. Unlike messages in groups or private chats, channels are not end-to-end encrypted. Channels were initially only available to users in Colombia and Singapore, then later Egypt, Chile, Malaysia, Morocco, Ukraine, Kenya and Peru before becoming widely available in September 2023.

###  Artificial intelligence 
In April 2024, an AI-powered "Smart Assistant" called Meta AI became widely available in WhatsApp, allowing users to ask it questions or have it complete tasks such as generating images. The assistant is based on the LLaMa 4 (previously LLaMa 3) model, and is also available on other Meta platforms like Facebook and Instagram. WhatsApp also introduced chat filters, allowing users to sort their chats by All, Unread or Groups.
In September 2024, WhatsApp expanded support for Meta AI, allowing users to send text and photos to Meta AI to ask questions, identify objects, translate text or edit pictures.
In December 2024, WhatsApp introduced a reverse image search feature, allowing users to verify image authenticity directly within the app using Google Search.

###  Parent-managed accounts 
In March 2026, WhatsApp introduced parent-managed accounts, a feature designed to give parents more oversight of their children's activity on the platform. The system allows parents to monitor contacts, review group participation, and manage certain privacy settings through parental controls. The feature is intended to provide additional supervision options for younger users using the app.

###  About 
In November 2025, WhatsApp announced that they would update their About feature, which allows users to add a short message to explain what they are doing. By default, it is set to disappear in 24 hours, but it can be set for a longer amount of time and can be restricted for viewing by other contacts in the Settings menu. According to WhatsApp, this update was made for the incoming Christmas period for users to inform their contacts on their activities during the holidays. Prior to the update, the feature was "largely hidden within the apps menus" and difficult to find, with the reason for updating being that WhatsApp wanted the feature to be used more often. Engadget called the revamped feature "WhatsApp’s version of an AIM away message" and likened it to Instagram's and Facebook's Notes.
The rollout to mobile users began the week of the announcement. The updated feature also allows users to reply directly to a contact's About message by tapping on it within a chat.

##  Platform support 
Currently, WhatsApp's principal platforms, which are fully supported, are devices supporting mobile telephony running Android, and iPhones. As of 2025, the software requires at least Android version 5.0 or iOS version 15.1 respectively. This table details platform support history.

###  Linked devices 
Linked devices are secondary devices running the WhatsApp messenger software. They link to and sync with WhatsApp actively running on a supported primary phone. Up to four linked devices can be added per user account. Linked devices automatically log out after 14 days of inactivity on the primary phone. Linked devices allow the service to be used on multiple other platforms like desktop computers and smartwatches (e.g. WhatsApp Web, Facebook Portal), but also on other smartphones (called companions).
Originally it was required for the primary phone to keep an online connection to WhatsApp for linked devices to work, but now WhatsApp can run on linked devices without such requirement. This ability (named multi-device support) began testing in July 2021 and rolled out to all users in April 2023.

####  WhatsApp Web 
WhatsApp was officially made available for PCs through a web client, under the name WhatsApp Web, released on January 21, 2015. WhatsApp Web is accessed through web.WhatsApp.com and access is granted after the user scans their personal QR code through their mobile WhatsApp client. The desktop version was first only available to Android, BlackBerry, and Windows Phone users. Later on, it also added support for iOS, Nokia Series 40, and Nokia S60 (Symbian).
Previously the WhatsApp user's handset had to be connected to the Internet for the browser application to function but as of an update in October 2021 (and integrated by default in WhatsApp as of April 2022) that is no longer the case. When this multi-device feature was first introduced to Android and iOS users, it could only show messages for the last three months on the Web version, because the Web version was syncing with the phone. Since the complete roll out of this feature, users cannot check old messages before this period on the Web version anymore.
There are similar unofficial WhatsApp solutions for macOS, such as the open-source ChitChat, previously known as WhatsMac.

####  Windows and Mac 
On May 10, 2016, the messenger was introduced for both Microsoft Windows and macOS operating systems. Support for video and voice calls from desktop clients was later added. Similar to the WhatsApp Web format, the app, which synchronises with a user's mobile device, is available for download on the website. It supported operating systems Windows 8 and OS X 10.10 and higher.
In 2023, WhatsApp replaced the Electron-based apps with native versions for their respective platforms. The Windows version is based on UWP while the Mac version is a port of the iOS version using Catalyst technology.
In July 2025, WhatsApp stopped developing the Windows UWP-based app due to poor support and deprecation of the UWP framework by Microsoft. WhatsApp for Windows transitioned over to the Microsoft Edge WebView2 framework, marking a return to utilising a web-based framework (just like Electron previously) instead of a native framework. The WebView2-based app has been criticised for its sluggish performance, high RAM usage, and requirement to keep the app running in the background to receive push notifications, compared to the previous native version.

####  iPad 
WhatsApp has been officially supported for iPads and its iPadOS since May 27, 2025. Similarly to WhatsApp for web, Windows, Mac, and smartwatches, the iPad is a type of linked device that connects and syncs to WhatsApp running on a smartphone.

####  Smartwatches 
WhatsApp added support for Android Wear (now called Wear OS) in 2014 and for the Apple Watch in 2025.

##  Technical 
WhatsApp uses a customized version of the open standard Extensible messaging and presence protocol (XMPP). A 2019 document released by the DOJ confirms this by naming "FunXMPP" as the protocol used by WhatsApp. The document was part of a lawsuit by WhatsApp and Meta against the NSO Group for their Pegasus malware. Upon installation, it creates a user account using the user's phone number as the username (Jabber ID: [phone number]@s.whatsapp.net).
WhatsApp automatically compares all the phone numbers from the device's address book with its central database of WhatsApp users to automatically add contacts to the user's WhatsApp contact list. Previously the Android and Nokia Series 40 versions used an MD5-hashed, reversed-version of the phone's IMEI as a password, while the iOS version used the phone's Wi-Fi MAC address instead of the IMEI. A 2012 update implemented generation of a random password on the server side. Alternatively a user can also contact any other WhatsApp user through the URL https://api.whatsapp.com/send/?phone=[phone number] where [phone number] is the number of the contact including the country code.
Some devices using dual SIMs may not be compatible with WhatsApp, though there are unofficial workarounds to install the app.
In February 2015, WhatsApp implemented voice calling, which helped WhatsApp to attract a different segment of the user population. WhatsApp's voice codec is Opus, which uses the modified discrete cosine transform (MDCT) and linear predictive coding (LPC) audio compression algorithms. WhatsApp uses Opus at 8–16 kHz sampling rates. On November 14, 2016, WhatsApp added video calling for users using Android, iPhone, and Windows Phone devices.
In November 2017, WhatsApp implemented a feature giving users seven minutes to delete messages sent by mistake.
Multimedia messages are sent by uploading the image, audio or video to be sent to an HTTP server and then sending a link to the content along with its Base64 encoded thumbnail, if applicable.
WhatsApp uses a "store and forward" mechanism for exchanging messages between two users. When a user sends a message, it is stored on a WhatsApp server, which tries to forward it to the addressee, and repeatedly requests acknowledgement of receipt. When the message is acknowledged, the server deletes it; if undelivered after 30 days, it is also deleted.

###  End-to-end encryption 
On November 18, 2014, Open Whisper Systems announced a partnership with WhatsApp to provide end-to-end encryption by incorporating the encryption protocol used in Signal into each WhatsApp client platform. Open Whisper Systems said that they had already incorporated the protocol into the latest WhatsApp client for Android, and that support for other clients, group/media messages, and key verification would be coming soon after. WhatsApp confirmed the partnership to reporters, but there was no announcement or documentation about the encryption feature on the official website, and further requests for comment were declined. In April 2015, German magazine Heise security used ARP spoofing to confirm that the protocol had been implemented for Android-to-Android messages, and that WhatsApp messages from or to iPhones running iOS were still not end-to-end encrypted. They expressed the concern that regular WhatsApp users still could not tell the difference between end-to-end encrypted messages and regular messages.
On April 5, 2016, WhatsApp and Open Whisper Systems announced that they had finished adding end-to-end encryption to "every form of communication" on WhatsApp, and that users could now verify each other's keys. Users were also given the option to enable a trust on first use mechanism to be notified if a correspondent's key changes. According to a white paper that was released along with the announcement, WhatsApp messages are encrypted with the Signal Protocol. WhatsApp calls are encrypted with SRTP, and all client-server communications are "layered within a separate encrypted channel".
On October 14, 2021, WhatsApp rolled out end-to-end encryption for backups on Android and iOS. The feature has to be turned on by the user and provides the option to encrypt the backup either with a password or a 64-digit encryption key.
The application can store encrypted copies of the chat messages onto the SD card, but chat messages are also stored unencrypted in the SQLite database file "msgstore.db".
WhatsApp uses the Sender Keys protocol.

###  WhatsApp Payments 
WhatsApp Payments (marketed as WhatsApp Pay) is a peer-to-peer money transfer feature. The service became generally available in India and Brazil, and in Singapore for WhatsApp Business transactions only.

####  India 
In July 2017, WhatsApp received permission from the National Payments Corporation of India (NPCI) to enter into partnership with multiple Indian banks, for transactions over Unified Payments Interface (UPI), which relies on mobile phone numbers to make account-to-account transfers. In November 2020, UPI payments via WhatsApp were initially restricted to 20 million users, and to 100 million users in April 2022, and became generally available to everyone in August 2022.

###  Facebook/WhatsApp cryptocurrency project, 2019–2022 
On February 28, 2019, The New York Times reported that Facebook was "hoping to succeed where Bitcoin failed" by developing an in-house cryptocurrency that would be incorporated into WhatsApp. The project reportedly involved more than 50 engineers under the direction of former PayPal president David A. Marcus. This "Facebook coin" would reportedly be a stablecoin pegged to the value of a basket of different foreign currencies.
In June 2019, Facebook said that the project would be named Libra, and that a digital wallet named "Calibra" was to be integrated into Facebook and WhatsApp. After financial regulators in many regions raised concerns, Facebook stated that the currency, renamed Diem since December 2020, would require a government-issued ID for verification, and the wallet app would have fraud protection. Calibra was rebranded to Novi in May 2020.
Meta (formerly Facebook) ended its Novi project on September 1, 2022.

##  Controversies and criticism 
###  Misinformation 
WhatsApp has repeatedly imposed limits on message forwarding in response to the spread of misinformation in countries including India and Australia. The measure, first introduced in 2018 to combat spam, was expanded and remained active in 2021. WhatsApp stated that the forwarding limits had helped to curb the spread of misinformation regarding COVID-19.

####  Murders in India 
In India, WhatsApp encouraged people to report messages that were fraudulent or incited violence after lynch mobs in India murdered innocent people because of malicious WhatsApp messages falsely accusing the victims of intending to abduct children. There were a series of incidents between 2017 and 2020, after which WhatsApp announced changes for Indian users of the platform that labels forwarded messages as such.

####  2018 elections in Brazil 
In an investigation on the use of social media in politics, it was found that WhatsApp was being abused for the spread of fake news in the 2018 presidential elections in Brazil. It was reported that US$3 million was spent in illegal concealed contributions related to this practice.
Researchers and journalists called on WhatsApp's parent company, Facebook, to adopt measures similar to those adopted in India and restrict the spread of hoaxes and fake news.

###  Security and privacy 
WhatsApp was initially criticized for its lack of encryption, sending information as plaintext. Encryption was first added in May 2012. End-to-end encryption was only fully implemented in April 2016 after a two-year process. As of September 2021, it is known that WhatsApp makes extensive use of outside contractors and artificial intelligence systems to examine certain user messages, images and videos (those that have been flagged by users as possibly abusive); and turns over to law enforcement metadata including critical account and location information.
In 2016, WhatsApp was widely praised for the addition of end-to-end encryption and earned a 6 out of 7 points on the Electronic Frontier Foundation's "Secure Messaging Scorecard". WhatsApp was criticized by security researchers and the Electronic Frontier Foundation for using backups that are not covered by end-to-end encryption and allow messages to be accessed by third-parties.
In 2019, Edward Snowden alarmed: "The problem with applications like WhatsApp is, it was actually designed to have very strong encryption, just the same as the gold standard today which would be the signal messenger or the wire messenger, but then it was bought by Facebook because it was so good, and now Facebook is quite aggressively reducing the security of WhatsApp about once a quarter, and they’re trying to do it as quietly as possible, so a messenger that the people are comfortable using now is actually a danger to you."
In May 2019, a security vulnerability in WhatsApp was found and fixed that allowed a remote person to install spyware by making a call which did not need to be answered.
In September 2019, WhatsApp was criticized for its implementation of a 'delete for everyone' feature. iOS users can elect to save media to their camera roll automatically. When a user deletes media for everyone, WhatsApp does not delete images saved in the iOS camera roll and so those users are able to keep the images. WhatsApp released a statement saying that "the feature is working properly", and that images stored in the camera roll cannot be deleted due to Apple's security layers.
In November 2019, WhatsApp released a new privacy feature that let users decide who can add them to groups.
In December 2019, WhatsApp confirmed a security flaw that would allow hackers to use a malicious GIF image file to gain access to the recipient's data. When the recipient opened the gallery within WhatsApp, even if not sending the malicious image, the hack is triggered and the device and its contents become vulnerable. The flaw was patched and users were encouraged to update WhatsApp.
On December 17, 2019, WhatsApp fixed a security flaw that allowed cyber attackers to repeatedly crash the messaging application for all members of group chat, which could only be fixed by forcing the complete uninstall and reinstall of the app. The bug was discovered by Check Point in August 2019 and reported to WhatsApp. It was fixed in version 2.19.246 onwards.
For security purposes, since February 1, 2020, WhatsApp has been made unavailable on smartphones using legacy operating systems like Android 2.3.7 or older and iPhone iOS 8 or older that are no longer updated by their providers.
In April 2020, the NSO Group held its governmental clients accountable for the allegation of human rights abuses by WhatsApp. In its revelation via documents received from court, the group claimed that the lawsuit brought against the company by WhatsApp threatened to infringe on its clients' "national security and foreign policy concerns". However, the company did not reveal names of the end users, which according to a research by Citizen Lab include, Saudi Arabia, Bahrain, Kazakhstan, Morocco, Mexico and the United Arab Emirates.
On December 16, 2020, a claim that WhatsApp gave Google access to private messages was included in the anti-trust case against the latter. As the complaint was heavily redacted due to being an ongoing case, it did not disclose whether this was alleged tampering with the app's end-to-end encryption, or Google accessing user backups.
In January 2021, WhatsApp announced an updated privacy policy which stated that WhatsApp would share user data with Facebook and its "family of companies" beginning February 2021. Previously, users could opt-out of such data sharing, but the new policy removed this option. The new privacy policy would not apply within the EU, as it is illegal under the GDPR. Facebook and WhatsApp were widely criticized for this move. The enforcement of the privacy policy was postponed from February 8 to May 15, 2021, WhatsApp announced they had no plans to limit the functionality of the app for those who did not approve the new terms.
On October 15, 2021, WhatsApp announced that it would begin offering an end-to-end encryption service for chat backups, meaning no third party (including both WhatsApp and the cloud storage vendor) would have access to a user's information. This new encryption feature added an additional layer of protection to chat backups stored either on Apple iCloud or Google Drive.
On November 29, 2021, an FBI document was uncovered by Rolling Stone, revealing that WhatsApp responds to warrants and subpoenas from law enforcement within minutes, providing user metadata to the authorities. The metadata includes the user's contact information and address book.
In January 2022, an unsealed surveillance application revealed that WhatsApp started tracking seven users from China and Macau in November 2021, based on a request from US DEA investigators. The app collected data on who the users contacted and how often, and when and how they were using the app. This is reportedly not an isolated occurrence, as federal agencies can use the Electronic Communications Privacy Act to covertly track users without submitting any probable cause or linking a user's number to their identity.
At the beginning of 2022, it was revealed that San Diego–based startup Boldend had developed tools to hack WhatsApp's encryption, gaining access to user data, at some point since the startup's inception in 2017. The vulnerability was reportedly patched in January 2021. Boldend is financed, in part, by Peter Thiel, a notable investor in Facebook.
In September 2022, a critical security issue in WhatsApp's Android video call feature was reported. An integer overflow bug allowed a malicious user to take full control of the victim's application once a video call between two WhatsApp users was established. The issue was patched on the day it was officially reported.
In 2025, WhatsApp alerted 90 journalists and other members of civil society that they had been targeted by spyware used by the Israeli technology company Paragon Solutions. In April 2025, a group of Austrian researchers were able to extract 3.5 billion users' phone numbers by being able to make a hundred million contact discovery requests an hour, a flaw that exposed previous warnings from researchers in 2017 were not addressed. The researchers notified Meta (who updated the enumeration problem in October), and deleted their copy of the phone numbers.

####  UK institutions 
As of 2023, WhatsApp is widely used by government institutions in the UK, although such use is viewed as problematical since it hinders the public, including journalists, from obtaining accurate government records when making freedom of information requests.
The information commissioner has said that the use of WhatsApp posed risks to transparency since members of Parliament, government ministers, and officials who wished to avoid scrutiny might use WhatsApp despite there being official channels. Transparency campaigners have challenged the practice in court.
Notably, during the COVID-19 pandemic, the UK government routinely used WhatsApp to make decisions on managing the crisis, including on personal rather than government-issued devices. When the official inquiry into the pandemic began seeking evidence in May 2023, this presented issues for its ability to gather the material it sought. A personal device of the former Prime Minister, Boris Johnson, had been compromised by a security breach, and it was claimed that it could not be switched on to recover messages. Further, the Cabinet Office had claimed that since many messages were not relevant to the inquiry, it only needed to hand over material it had 
selected as being relevant. The High Court, in a judicial review sought by the Cabinet Office, declared that all documents sought by the inquiry were to be handed over unredacted.
In 2018, it was reported that around 500,000 National Health Service (NHS) staff used WhatsApp and other instant messaging systems at work and around 29,000 had faced disciplinary action for doing so. Higher usage was reported by frontline clinical staff to keep up with care needs, even though NHS trust policies do not permit their use.

####  Mods and fake versions 
In March 2019, WhatsApp released a guide for users who had installed unofficial modified versions of WhatsApp and warned that it may ban those using unofficial clients.

####  WhatsApp snooping scandal 
In May 2019, WhatsApp was attacked by hackers who installed spyware on a number of victims' smartphones. The hack, allegedly developed by Israeli surveillance technology firm NSO Group, injected malware onto WhatsApp users' phones via a remote-exploit bug in the app's Voice over IP calling functions. A Wired report noted the attack was able to inject malware via calls to the targeted phone, even if the user did not answer the call.
In October 2019, WhatsApp filed a lawsuit against NSO Group in a San Francisco court, claiming that the alleged cyberattack violated US laws including the Computer Fraud and Abuse Act (CFAA). According to WhatsApp, the exploit "targeted at least 100 human-rights defenders, journalists and other members of civil society" among a total of 1,400 users in 20 countries.
In April 2020, the NSO Group held its governmental clients accountable for the allegation of human rights abuses by WhatsApp. In its revelation via documents received via court, the group claimed that the lawsuit brought against the company by WhatsApp threatened to infringe on its clients' "national security and foreign policy concerns". However, the company did not reveal the names of the end users, which according to research by Citizen Lab include, Saudi Arabia, Bahrain, Kazakhstan, Morocco, Mexico and the United Arab Emirates.
In July 2020, a US federal judge ruled that the lawsuit against NSO group could proceed. NSO Group filed a motion to have the lawsuit dismissed, but the judge denied all of its arguments.

####  Jeff Bezos phone hack 
In January 2020, a digital forensic analysis revealed that the Amazon founder Jeff Bezos received an encrypted message on WhatsApp from the official account of Saudi Arabia's Crown Prince Mohammed bin Salman. The message reportedly contained a malicious file, the receipt of which resulted in Bezos' phone being hacked. The United Nations' special rapporteur David Kaye and Agnes Callamard later confirmed that Jeff Bezos' phone was hacked through WhatsApp, as he was one of the targets of Saudi's hit list of individuals close to The Washington Post journalist Jamal Khashoggi.

####  FBI 
In 2021, an FBI document obtained through a Freedom of Information request by Property of the People, Inc., a 501(c)(3) nonprofit organization, revealed that WhatsApp and iMessage are vulnerable to law-enforcement real-time searches.

####  Tek Fog 
In January 2022, an investigation by The Wire claimed that BJP, an Indian political party, allegedly used an app called Tek Fog which was capable of hacking inactive WhatsApp accounts en masse to mass message their contacts with propaganda. According to the report, a whistleblower with app access was able to hack a test WhatsApp account controlled by reporters "within minutes." It was later determined that staff of their Meta investigative team had been duped by false information; The Wire fired the staff member involved and issued a formal apology to its readers.

###  Terrorism 
In December 2015, it was reported that terrorist organization ISIS had been using WhatsApp to plot the November 2015 Paris attacks. According to The Independent, ISIS also uses WhatsApp to traffic sex slaves.
In March 2017, British Home Secretary Amber Rudd said encryption capabilities of messaging tools like WhatsApp are unacceptable, as news reported that Khalid Masood used the application several minutes before perpetrating the 2017 Westminster attack. Rudd publicly called for police and intelligence agencies to be given access to WhatsApp and other encrypted messaging services to prevent future terror attacks.
In April 2017, the perpetrator of the Stockholm truck attack reportedly used WhatsApp to exchange messages with an ISIS supporter shortly before and after the incident. The messages involved discussing how to make an explosive device and a confession to the attack.
In April 2017, nearly 300 WhatsApp groups with about 250 members each were reportedly being used to mobilize stone-pelters in Jammu and Kashmir to disrupt security forces' operations at encounter sites. According to police, 90% of these groups were closed down after police contacted their admins. Further, after a six-month probe which involved the infiltration of 79 WhatsApp groups, the National Investigation Agency reported that out of about 6386 members and admins of these groups, about 1000 were residents of Pakistan and gulf nations. Further, for their help in negating anti-terror operations, the Indian stone pelters were getting funded through barter trade from Pakistan and other indirect means.
In May 2022, the FBI stated that an ISIS sympathizer, who was plotting to assassinate George W. Bush, was arrested based on his WhatsApp data. According to the arrest warrant for the suspect, his WhatsApp account was placed under surveillance.

###  Scams and malware 
There are numerous ongoing scams on WhatsApp that let hackers spread viruses or malware. In May 2016, some WhatsApp users were reported to have been tricked into downloading a third-party application called WhatsApp Gold, which was part of a scam that infected the users' phones with malware. A message that promises to allow access to their WhatsApp friends' conversations, or their contact lists, has become the most popular hit against anyone who uses the application in Brazil. Clicking on the message actually sends paid text messages. Since December 2016, more than 1.5 million people have clicked and lost money.
Another application called GB WhatsApp is considered malicious by cybersecurity firm Symantec because it usually performs some unauthorized operations on end-user devices.

###  Bans 
####  China 
WhatsApp is owned by Meta, whose main social media service Facebook has been blocked in China since 2009. In September 2017, security researchers reported to The New York Times that the WhatsApp service had been completely blocked in China. On April 19, 2024, Apple removed WhatsApp from the App Store in China, citing government orders that stemmed from national security concerns.

####  Iran 
On May 9, 2014, the government of Iran announced that it had proposed to block the access to WhatsApp service to Iranian residents. "The reason for this is the assumption of WhatsApp by the Facebook founder Mark Zuckerberg, who is an American Zionist", said Abdolsamad Khorramabadi, head of the country's Committee on Internet Crimes. Subsequently, Iranian president Hassan Rouhani issued an order to the Ministry of ICT to stop filtering WhatsApp. It was once again blocked in September 2022 but unblocked in December 2024.

####  Turkey 
Turkey temporarily banned WhatsApp in 2016, following the assassination of the Russian ambassador to Turkey.

####  Brazil 
On March 1, 2016, Diego Dzodan, Facebook's vice-president for Latin America was arrested in Brazil for not cooperating with an investigation in which WhatsApp conversations were requested. On March 2, 2016, at dawn the next day, Dzodan was released because the Court of Appeal held that the arrest was disproportionate and unreasonable.
On May 2, 2016, mobile providers in Brazil were ordered to block WhatsApp for 72 hours for the service's second failure to cooperate with criminal court orders. Once again, the block was lifted following an appeal, after less than 24 hours.
Brazil's Central Bank issued an order to payment card companies Visa and Mastercard on June 23, 2020, to stop working with WhatsApp on its new electronic payment system. A statement from the Bank asserted the decision to block the Facebook-owned company's latest offering was taken to "preserve an adequate competitive environment" in the mobile payments space and to ensure "functioning of a payment system that's interchangeable, fast, secure, transparent, open and cheap."

####  Uganda 
The government of Uganda banned WhatsApp and Facebook, along with other social media platforms, to enforce a tax on the use of social media. Users are to be charged USh.200/= per day to access these services according to the new law set by parliament.

####  United Arab Emirates (UAE) 
The United Arab Emirates banned WhatsApp video chat and VoIP call applications in as early as 2013 due to what is often reported as an effort to protect the commercial interests of their home grown nationally owned telecom providers (du and Etisalat). Their app ToTok has received press suggesting it is able to spy on users.

####  Cuba 
In July 2021, the Cuban government blocked access to several social media platforms, including WhatsApp, to curb the spread of information during the anti-government protests.

####  Switzerland 
In December 2021, the Swiss army banned the use of WhatsApp and several other non-Swiss encrypted messaging services by army personnel. The ban was prompted by concerns of US authorities potentially accessing user data for such apps because of the CLOUD Act. The army recommended that all army personnel use Threema instead, as the service is based in Switzerland.

####  Zambia 
In August 2021, the digital rights organization Access Now reported that WhatsApp along with several other social media apps was being blocked in Zambia for the duration of the general election. The organization reported a massive drop-off in traffic for the blocked services, though the country's government made no official statements about the block.

####  Saudi Arabia 
The Saudi Central Bank (SAMA) has prohibited local banks from using instant messaging applications like WhatsApp for customer communication. This decision aims to enhance data security and protect customer information.

####  Russia 
In Russia, authorities increased pressure on WhatsApp in late 2025. On 28 November 2025, officials warned of a potential full ban on the service. On 11 February 2026, the Russian government fully blocked WhatsApp, which had at least 100 million users in the country until recently, citing its alleged failure to comply with domestic regulations concerning extremist content and state oversight requirements.
As per the BBC report, the decision had been made "due to Meta's unwillingness to comply with the norms and the letter of Russian law". Meta could resume operations, if it complies with the law and enters into dialogue.

####  Third-party clients 
In mid-2013, WhatsApp Inc. filed for the DMCA takedown of the discussion thread on the XDA Developers forums about the then popular third-party client "WhatsApp Plus".
In 2015, some third-party WhatsApp clients that were reverse-engineering the WhatsApp mobile app, received a cease and desist to stop activities that were violating WhatsApp legal terms. As a result, users of third-party WhatsApp clients were also banned.

##  WhatsApp Business 
WhatsApp launched two business-oriented apps in January 2018, separated by the intended userbase:

A WhatsApp Business app for small companies
An Enterprise Solution known as WhatsApp Business Platform for bigger companies with global customer bases, such as airlines, e-commerce retailers and banks, who would be able to offer customer service and conversational commerce (e-commerce) via WhatsApp chat, using live agents or chatbots (as far back as 2015, companies like Meteordesk had provided unofficial solutions for enterprises to attend to large numbers of users, but these were shut down by WhatsApp)
This solution was originally available as on-premise only, but in 2022, WhatsApp Cloud API became available. The on-premise API has been deprecated and will be fully sunset on October 23, 2025.
As WhatsApp API does not have a frontend interface, businesses need to subscribe through one of Meta's approved Business Solution Providers. Examples of these include respond.io, Gupshup, Trengo, Wati and Manychat.
In October 2020, Facebook announced the introduction of pricing tiers for services offered via the WhatsApp Business API, charged on a per-conversation basis. On July 1, 2025, a new pricing tier system came into effect which charges per-message rather than per-conversation.
In May 2026, WhatsApp launched AI-powered business tools in India for small businesses, enabling automated customer interactions, marketing assistance, and support services through WhatsApp Business.

##  User statistics 
WhatsApp handled ten billion messages per day in August 2012, growing from two billion in April 2012, and one billion the previous October. On June 13, 2013, WhatsApp announced that they had reached their new daily record by processing 27 billion messages. According to the Financial Times, WhatsApp "has done to SMS on mobile phones what Skype did to international calling on landlines".
By April 22, 2014, WhatsApp had over 500 million monthly active users, 700 million photos and 100 million videos were being shared daily, and the messaging system was handling more than 10 billion messages each day.
On August 24, 2014, Koum announced on his Twitter account that WhatsApp had over 600 million active users worldwide. At that point WhatsApp was adding about 25 million new users every month, or 833,000 active users per day.
In May 2017, it was reported that WhatsApp users spend over 340 million minutes on video calls each day on the app. This is the equivalent of roughly 646 years of video calls per day.
By February 2017, WhatsApp had over 1.2 billion users globally, reaching 1.5 billion monthly active users by the end of 2017.
In January 2020, WhatsApp reached over 5 billion installs on Google Play Store making it only the second non-Google app to achieve this milestone.
In February 2020, WhatsApp had over 2 billion users globally.
In May 2025, Meta reported WhatsApp had over 3 billion monthly active users globally.

###  Specific markets 
India is by far WhatsApp's largest market in terms of total number of users. In May 2014, WhatsApp crossed 50 million monthly active users in India, which is also its largest country by the number of monthly active users, then 70 million in October 2014, making users in India 10% of WhatsApp's total user base. In February 2017, WhatsApp reached 200 million monthly active users in India.
Israel is one of WhatsApp's strongest markets in terms of ubiquitous usage. According to Globes, already by 2013 the application was installed on 92% of all smartphones, with 86% of users reporting daily use.
In July 2024, WhatsApp reached 100 million users in the United States.

###  Competition 
WhatsApp competes with messaging services including iMessage (estimated 1.3 billion active users), WeChat (1.26 billion active users), Telegram (1 billion users), Viber (260 million active users), LINE (217 million active users), KakaoTalk (57 million active users), and Signal (70 million active users). Both Telegram and Signal in particular were reported to get registration spikes during WhatsApp outages and controversies.
WhatsApp has increasingly drawn its innovation from competing services, such as a Telegram-inspired web version and features for groups. In 2016, WhatsApp was accused of copying features from a then-unreleased version of iMessage.

##  See also 
Comparison of cross-platform instant messaging clients
Comparison of user features of messaging platforms
Comparison of VoIP software – Voice over IP software comparison
Criticism of Facebook
Instagram – Social media platform owned by Meta
List of most-downloaded Google Play applications
List of most popular social platforms

##  References 
##  External links 
Official website
