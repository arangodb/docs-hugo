# Sundar Pichai

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/Sundar_Pichai>*

Pichai Sundararajan (born June 10, 1972), better known as Sundar Pichai (pronounced: ), is an Indian–American business executive who has been the CEO of Google since 2015 and the CEO of its parent company Alphabet Inc. since 2019.
Pichai began his career as a materials engineer. Following a short stint at the management consulting firm McKinsey & Co., Pichai joined Google in 2004, where he led the product management and innovation efforts for a suite of Google's client software products, including Google Chrome and ChromeOS, as well as being largely responsible for Google Drive. In addition, he went on to oversee the development of other applications such as Gmail and Google Maps.
As of February 2026, his net worth is estimated at US$1.6 billion.

##  Early life and education 
Pichai was born on June 10, 1972 in Madurai, Tamil Nadu, to a Tamil Hindu family. His mother, Lakshmi, was a stenographer, and his father, Regunatha Pichai, was an electrical engineer at GEC, the British conglomerate.
Pichai completed schooling in Jawahar Vidyalaya Senior Secondary School in Ashok Nagar, Chennai and completed the Class XII from Vana Vani school at IIT Madras. He earned a B.Tech in metallurgical engineering from IIT Kharagpur in 1993. He holds an MS from Stanford University School of Engineering in materials science and engineering and an MBA from the Wharton School, where he was named a Siebel Scholar and a Palmer Scholar, respectively.

##  Career 
Pichai worked in engineering and product management at Applied Materials and in management consulting at McKinsey & Company. Pichai joined Google in 2004, where he led the product management and innovation efforts for a suite of Google's client software products, including Google Chrome and ChromeOS, as well as being largely responsible for Google Drive. He went on to oversee the development of other applications such as Gmail and Google Maps. On November 19, 2009, Pichai gave a demonstration of ChromeOS; the Chromebook was released for trial and testing in 2011, and released to the public in 2012. On May 20, 2010, he announced the open-sourcing of the new video codec VP8 by Google and introduced the new video format, WebM. Pichai served on Jive Software's board of directors from April 2011 to July 2013.
On March 13, 2013, Pichai added Android to the list of Google products that he oversaw. Android was formerly managed by Andy Rubin. Pichai was selected to become the next CEO of Google on August 10, 2015, after previously being appointed Product Chief by CEO, Larry Page. On October 24, 2015, he stepped into the new position at the completion of the formation of Alphabet Inc., the new holding company for the Google company family.
Pichai had been suggested as a contender for Microsoft's CEO in 2014, a position that was eventually given to Satya Nadella. In August 2017, Pichai drew publicity for firing a Google employee who wrote a ten-page manifesto criticizing the company's pro-diversity policies.
Pichai was appointed to the Alphabet Board of Directors in 2017.
On December 11, 2018, Sundar Pichai was questioned by the United States House Judiciary Committee on a range of Google-related issues such as possible political bias on Google's platforms, the company's alleged plans for a "censored search app" in China, and its privacy practices. In response, Pichai told the committee that Google employees cannot influence search results. He also stated that Google users can opt out of having their data collected and that "there are no current plans for a censored search engine" in China.
In December 2019, Pichai became the CEO of Alphabet Inc. His compensation from the company topped $200 million in 2022, which many employees criticized in light of large scale layoffs that Google undertook in 2023.
In April 2024, after 28 Google employees were fired for protesting against Project Nimbus, Pichai stated that the office is not a place "to fight over disruptive issues or debate politics", and warned against using the company "as a personal platform".

##  Awards and recognition 
Pichai was included in Time's annual list of the 100 most influential people in 2016 and 2020. He was also included in the Time 100 AI list in 2024. He was awarded the 2021 Asia Game Changer Award by the Asia Society.
In 2022, Pichai received the Padma Bhushan in the category of Trade and Industry from the Government of India, the country's third-highest civilian award.

##  Personal life 
Pichai is married to Anjali Pichai (née Haryani) and has two children. Anjali is originally from Kota, India. They became close while studying together at IIT Kharagpur. His recreational interests include cricket and soccer. He lives in Los Altos Hills, California.

##  References 
##  Further reading 
##  External links 
Sundar Pichai on X 
"Sundar Pichai's rise to fame in 90 seconds", Tech Gurus, The Daily Telegraph
