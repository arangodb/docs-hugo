# Larry Ellison

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/Larry_Ellison>*

Lawrence Joseph Ellison (born August 17, 1944) is an American businessman. He co-founded the software company Oracle Corporation, and was its CEO from 1977 to 2014. He now serves as its CTO and executive chairman. According to Forbes, as of early 2026, Ellison's estimated net worth is $201–203 billion, making him the world's sixth-richest person. 
On September 10, 2025, Ellison was briefly the wealthiest person in the world after an increase in Oracle stock price, with an estimated net worth of $393 billion. He is also known for various other investments, such as his ownership of 98% of the land on Lānaʻi, the sixth-largest of the Hawaiian Islands, his stake in the automotive and clean energy company Tesla, Inc. worth over $19 billion, and his controlling stake in the mass media conglomerate Paramount Skydance, which is managed by his son David Ellison.

##  Early life and education 
Ellison was born on August 17, 1944, in New York City. His mother, Florence Spellman, is Jewish. His biological father was an Italian-American United States Army Air Corps pilot. After Ellison contracted pneumonia at the age of nine months, Spellman gave Ellison to Spellman's aunt and uncle for adoption. Ellison did not meet Spellman again until he was 48.
Ellison moved with his adoptive parents to Chicago's South Shore, a middle-class neighborhood with a significant Jewish population. He remembers his adoptive mother, Lillian Spellman Ellison, as warm and loving. He found his adoptive father, Louis Ellison, to be austere, unsupportive, and often distant. A government employee who had made a small fortune in Chicago real estate, only to lose it during the Great Depression, Louis had chosen his last name to honor Ellis Island, his point of entry into the United States.
Ellison was raised in a Reform Jewish home by his adoptive parents, who attended synagogue regularly, but he remained a religious skeptic. At age 13, Ellison refused to have a bar mitzvah celebration. Ellison said: "While I think I am religious in one sense, the particular dogmas of Judaism are not dogmas I subscribe to. I don't believe that they are real. They're interesting stories. They're interesting mythology, and I certainly respect people who believe these are literally true, but I don't. I see no evidence for this stuff." Ellison says that his fondness for Israel is not connected to religious sentiments but rather due to Israelis' innovative spirit in the technology sector.
Ellison attended South Shore High School in Chicago, was admitted to the University of Illinois at Urbana–Champaign, and enrolled as a pre-med student. At the university, he was named science student of the year. He withdrew without taking final exams after his sophomore year because his adoptive mother had just died. After spending the summer of 1966 in California, he then attended the University of Chicago for one term, where he studied physics and mathematics and also first encountered computer design. He then moved to Berkeley, California, and began his career as a computer programmer for several different companies.

##  Career and Oracle 
###  1977–1994 
During the 1970s, after a brief stint at Amdahl Corporation, Ellison began working for Ampex Corporation. His first project included a database for the CIA, code-named "Oracle". Ellison was inspired by a paper written by Edgar F. Codd on relational database systems called "A Relational Model of Data for Large Shared Data Banks". In 1977, Ellison, Ed Oates and Bruce Scott joined Software Development Laboratories (SDL) several months after it was founded by Ellison's supervisor at Ampex, Bob Miner. They invested $2,000 (equivalent to $10,626 in 2025), of which $1,200 (equivalent to $6,376 in 2025) was Ellison's. Although he had strong technical skills—Ellison was not officially categorized as a developer until about 1984—the founders decided that as the others were stronger technically, he would run sales.
In 1979, the company renamed itself Relational Software, Inc. (RSI). Ellison had heard about the IBM System R database, also based on Codd's theories, and wanted Oracle to achieve compatibility with it, but IBM made this impossible by refusing to share System R's error codes. The initial release of the Oracle Database in 1979 was called Oracle version 2; there was no Oracle version 1. In 1983, the company officially became Oracle Systems Corporation (named after its flagship product). In 1990, Oracle laid off 10% of its workforce (about 400 people) because it was losing money. This crisis, which almost resulted in the company's bankruptcy, came about because of Oracle's "up-front" marketing strategy, in which sales people urged potential customers to buy the largest possible amount of software all at once. The sales people then booked the value of future license sales in the current quarter, thereby increasing their bonuses. This became a problem when those future sales failed to materialize. Oracle eventually had to restate its earnings twice, and had to settle class-action lawsuits arising from its having overstated its earnings. Ellison later said that Oracle had made "an incredible business mistake".
Although IBM dominated the mainframe relational database market with its DB2 and SQL/DS database products, it delayed entering the market for a relational database on Unix and Windows operating systems. This left the door open for Sybase, Oracle, Ingres, Informix, and eventually Microsoft to dominate mid-range systems and microcomputers. Around this time, Oracle fell behind Sybase. From 1990 to 1993, Sybase was the fastest-growing database company and the database industry's darling vendor. In 1993, Sybase sold the rights to its database software running under the Windows operating system to Microsoft Corporation, which now markets it under the name "SQL Server". Sybase soon fell victim to merger mania; its 1996 merger with Powersoft resulted in a loss of focus on its core database technology.
In 1990, Ellison was named Entrepreneur of the Year by Harvard University.

###  1994–2010 
In 1994, Informix overtook Sybase and became Oracle's most important rival. The intense war between Informix CEO Phil White and Ellison was front-page Silicon Valley news for three years. In April 1997, Informix announced a major revenue shortfall and earnings restatements. White eventually landed in jail. Also in 1997, Ellison was made a director of Apple Computer after Steve Jobs returned to the company. Ellison resigned from that position in 2002. 
With the defeat of Informix and Sybase, Oracle enjoyed industry dominance until the rise of Microsoft SQL Server in the late 1990s and IBM's acquisition of Informix Software in 2001 to complement its DB2 database. By 2013 Oracle's main competition for new database licenses on UNIX, Linux, and Windows operating systems came from IBM's DB2 and from Microsoft SQL Server. IBM's DB2 still dominated the mainframe database market.
In 2005, Ellison agreed to settle a four-year-old insider-trading lawsuit by offering to pay $100 million (equivalent to $160,000,000 in 2025) to charity in Oracle's name.
In 2005, Oracle Corporation paid Ellison a $975,000 salary (equivalent to $1,600,000 in 2025), a $6,500,000 bonus (equivalent to $11,000,000 in 2025), and other compensation of $955,100 (equivalent to $1,600,000 in 2025). In 2007, Ellison earned a total compensation of $61,180,524 (equivalent to $95,000,000 in 2025), which included a base salary of $1,000,000 (equivalent to $1,600,000 in 2025), a cash bonus of $8,369,000 (equivalent to $13,000,000 in 2025), and options granted of $50,087,100 (equivalent to $77,800,000 in 2025). In 2008, he earned a total compensation of $84,598,700 (equivalent to $127,000,000 in 2025), which included a base salary of $1,000,000 (equivalent to $1,500,000 in 2025), a cash bonus of $10,779,000 (equivalent to $16,000,000 in 2025), no stock grants, and options granted of $71,372,700 (equivalent to $110,000,000 in 2025). In the year ending May 31, 2009, he made $56.8 million (equivalent to $85,000,000 in 2025). 
In 2006, Forbes ranked him as the richest Californian. In April 2009, after a tug-of-war with IBM and Hewlett-Packard, Oracle announced its intent to buy Sun Microsystems. 
In July 2009, for the fourth year in a row, Oracle's board awarded Ellison another 7 million stock options. In August 2009, it was reported that Ellison would be paid only $1 for his base salary for the fiscal year 2010, down from the $1,000,000 (equivalent to $1,500,000 in 2025) he was paid in fiscal 2009.

###  Since 2010 
After approval from regulators in the United States and the European Union, Oracle acquired its competitor Sun Microsystems on January 21, 2010. The Sun acquisition also gave Oracle control of the popular MySQL open source database, which Sun had acquired in 2008. In August 2010, Ellison denounced Hewlett-Packard's board for firing CEO Mark Hurd, writing: "The HP board just made the worst personnel decision since the idiots on the Apple board fired Steve Jobs many years ago." Ellison and Hurd were close personal friends. In September, Oracle hired Hurd as co-president alongside Safra Catz. Ellison remained in his CEO role.
Ellison was an early investor in Theranos. He is played by Hart Bochner in the 2022 miniseries The Dropout, about Theranos and its founder Elizabeth Holmes. 
In March 2010, the Forbes list of billionaires ranked Ellison as the sixth-richest person in the world and as the third-richest American, with an estimated net worth of over $28 billion (equivalent to $41,000,000,000 in 2025). In July 2010, The Wall Street Journal reported that Ellison was the highest-paid executive in the last decade, collecting a total compensation of US$1.84 billion (equivalent to $3,000,000,000 in 2025). In September 2011, Ellison was listed on the Forbes list of billionaires as the fifth richest man in the world and was still the third richest American, with a net worth of about $36.5 billion (equivalent to $52,000,000,000 in 2025). In September 2012, Ellison was again listed on the Forbes list of billionaires as the third richest American citizen with a net worth of $44 billion (equivalent to $62,000,000,000 in 2025). In October 2012, he was listed as the eighth-richest person in the world, according to the Bloomberg Billionaires Index. 
Ellison owns stakes in Salesforce.com, NetSuite, Quark Biotechnology Inc. and Astex Pharmaceuticals. In June 2012, Ellison agreed to buy 98 percent of the Hawaiian island of Lānaʻi from David H. Murdock's company, Castle & Cooke. The price was reported to be between $500 million (equivalent to $700,000,000 in 2025) and $600 million (equivalent to $840,000,000 in 2025). In 2013, according to The Wall Street Journal, Ellison earned $94.6 million (equivalent to $130,000,000 in 2025). On September 18, 2014, Ellison appointed Mark Hurd to CEO of Oracle from his former position as president; Safra Catz was also made CEO, moving from her former role as CFO. Ellison assumed the positions of chief technology officer and executive chairman.
In November 2016, Oracle bought NetSuite for $9.3 billion (equivalent to $12,000,000,000 in 2025). Ellison owned 35% of NetSuite at the time of the purchase making him $3.5 billion personally (equivalent to $4,700,000,000 in 2025).
In 2017, Forbes estimated that Ellison was the 4th-richest person in the technology sector.
In June 2018, Ellison's net worth was about $54.5 billion (equivalent to $70,000,000,000 in 2025), according to Forbes.
In December 2018, Ellison became a director on the board of Tesla, Inc., after purchasing 3 million shares earlier that year. Ellison left the Tesla board in August 2022.
In June 2020, Ellison was reported to be the seventh-wealthiest person in the world, with a net worth of $66.8 billion (equivalent to $83,000,000,000 in 2025).
In late 2022, Ellison owned 42.9% of the shares of Oracle Corporation, and in June 2023, he owned 1.4% of the shares of Tesla.
Ellison's software startup, Project Ronin, which he co-founded with David Agus and Dave Hodgson, closed in 2024. The company intended to transform cancer care using products intended to quickly analyze data within electronic medical records systems.
In August 2025, Ellison provided funding through his family trust for the merger of Paramount Global with his son David's Skydance Media. The trust remains the largest owner of the new company's shares while David retains operational control. On September 10, 2025, Ellison was briefly the wealthiest person in the world, with an estimated net worth of $393 billion.
In 2026, President Trump appointed Ellison to the President's Council of Advisors on Science and Technology (PCAST).

##  Political involvement 
Ellison was critical of NSA whistle-blower Edward Snowden, saying, "Snowden had yet to identify a single person who had been 'wrongly injured' by the NSA's data collection". In 2012, he donated to both Democratic and Republican politicians, and in late 2014 hosted Republican senator Rand Paul at a fundraiser at his home.
Since 2016, Ellison has been supporting Republicans; he was one of the top donors ($4 million by February 2016, equivalent to $5,000,000 in 2025) to Conservative Solutions PAC, a super PAC supporting Marco Rubio's 2016 presidential bid. He has called Rubio a centrist. In 2020, Ellison allowed President Donald Trump to have a fundraiser at his Rancho Mirage estate, but Ellison was not present. In January 2022, Ellison donated $15 million (equivalent to $17,000,000 in 2025) to the Opportunity Matters Fund super PAC associated with Senator Tim Scott, one of the biggest financial contributions of the 2022 midterm elections.
The Washington Post reported in May 2022 that Ellison participated in a conference call days after the 2020 U.S. presidential election that focused on strategies for challenging the legitimacy of the vote. Other participants on the call included Fox News host Sean Hannity, Senator Lindsey Graham, Trump personal attorney Jay Sekulow, and James Bopp, an attorney for True the Vote. The Post cited court documents and a participant on the call. In January 2025, Ellison joined Sam Altman of OpenAI and Masayoshi Son of Softbank at the White House to announce The Stargate Project.
In 2017, Ellison donated $16.6 million (equivalent to $21,800,000 in 2025) to the Friends of the Israel Defense Forces (FIDF), saying, "Since Israel's founding, we have called on the brave men and women of the IDF to defend our home". This was the largest donation in the organization's history. 
In 2019, Ellison helped fund an archaeological excavation project in East Jerusalem that was criticized by Palestinians, Israeli peace activists, and some archaeologists. A $1 billion (equivalent to $1,300,000,000 in 2025) lawsuit was filed in 2019 against several Israel supporters, including Ellison, accusing them of conspiring to ethnically cleanse Palestinians from Israeli-occupied territories, committing war crimes, and funding genocide. The case was dismissed in February 2024. 
Ellison lobbied Israeli mogul Arnon Milchan to drop his lawyer so that Benjamin Netanyahu could hire the lawyer for one of his corruption cases. In 2021, Ellison offered Netanyahu a board seat at Oracle. The same year, Netanyahu and his family vacationed on Lānaʻi, an island Ellison owns in Hawaii.

##  Personal life 
###  Marriages 
Ellison has been married six times:

Ellison married Adda Quinn in 1967. They divorced in 1974.
Ellison married Nancy Wheeler Jenkins shortly after meeting her in late 1976. In 1978, they divorced and Wheeler sold back her shares in Oracle (SDL at the time) to Ellison for $500.
Ellison was married to Barbara Boothe from 1983 to 1986. Boothe was a former receptionist at Oracle (RSI at the time). They had two children, David and Megan, who were (as of 2024) film producers at Skydance Media and Annapurna Pictures, respectively.
On December 18, 2003, Ellison married Melanie Craft, a romance novelist, at his Woodside estate. Ellison's friend Steve Jobs, former CEO and co-founder of Apple Inc., was the official wedding photographer, and Representative Tom Lantos officiated. They divorced in 2010.
In 2015, Ellison married Nikita Kahn. They separated in December 2016 and their divorce was finalized in 2020.
As of 2024, Ellison was married to Jolin (Keren) Ellison (née Zhu), an alumna of the University of Michigan. They have four children.

###  Health 
Ellison has said he abstains from alcohol and drugs because he "can't stand anything that clouds my mind". He is also known for his strict diet and exercise regimen.

###  Cars 
Ellison owns many exotic cars, including a Lexus LFA, an Audi R8, and a McLaren F1. His favorite was the Acura NSX, which he gave as gifts each year during its production.

###  Art 
Ellison owns at least four Vincent van Gogh paintings. His collection includes Bridge across the Seine at Asnières.

###  Homes 
Ellison styled his estimated $110 million Woodside, California, estate after feudal Japanese architecture, complete with a man-made 2.3-acre (0.93 ha) lake and an extensive seismic retrofit. In 2004 and 2005 he purchased more than 12 properties in Malibu, California, worth more than $180 million. The $65 million Ellison spent on five contiguous lots at Malibu's Carbon Beach made this the most costly residential transaction in U.S. history until banker Ronald Perelman sold his Palm Beach, Florida, compound for $70 million later that year. The entertainment system at his Pacific Heights home cost $1 million, and includes a rock concert-sized video projector at one end of a drained swimming pool, using the gaping hole as a giant subwoofer.
In early 2010, Ellison purchased the Astors' Beechwood Mansion—formerly the summer home of the Astor family—in Newport, Rhode Island, for $10.5 million.
In 2011, he purchased the 249-acre Porcupine Creek Estate and private golf course in Rancho Mirage, California for $42.9 million. The property was formerly the home of Yellowstone Club founders Edra and Tim Blixseth, and was sold to Ellison by creditors following their divorce and bankruptcy.
In 2022, Ellison bought a 22-acre property in Manalapan, Florida, for $173 million. He purchased it from Jim Clark, who in turn had acquired it from the Ziff family. It is the most expensive residential property purchase in Florida history.

####  Lanai 
In December 2020, he left California and moved to the island of Lānaʻi, where he owns 98 percent of the land. In subsequent years, tensions have been reported between Ellison's businesses on the island and some residents over housing and access. A 2022 Bloomberg feature described Ellison as a contemporary king of Lānaʻi. The report said many Lānaʻi residents both work for and rent from Ellison's companies, with commercial tenants commonly on short 30-day leases and some residential leases including provisions allowing termination of tenancy upon loss of employment. 
In August 2022, Maui County warned Ellison's Lānaʻi Resorts not to block public access to Hulopoʻe Beach Park, but the park's gate was closed anyway. The company said the closure was due to flooding, but local residents disputed that and the duration of the closure. In 2023, the Ellison-owned Lānaʻi Water Company put a significant multiyear rate increase before regulators citing infrastructure and operating costs. This drew concern about affordability from some customers.

###  Aviation 
Ellison is a licensed pilot and has owned several aircraft. In 1999, the city of San Jose, California, cited him for violating its limits on late-night takeoffs and landings from San Jose Mineta International Airport by planes weighing more than 75,000 pounds (34,019 kg). In January 2000, Ellison sued over the interpretation of the airport rule, contending that his Gulfstream V aircraft "is certified by the manufacturer to fly at two weights: 75,000 pounds, and at 90,000 pounds for heavier loads or long flights requiring more fuel. But the pilot only lands the plane in San Jose when it weighs 75,000 pounds or less, and has the logs to prove it." US District Judge Jeremy Fogel ruled in Ellison's favor in June 2001, calling for a waiver for Ellison's jet, but did not invalidate the curfew.
Ellison also owns at least two military jets: the Italian training aircraft SIAI-Marchetti S.211 and a decommissioned Soviet MiG-29 fighter, which the US government has refused him permission to import.

###  Movie cameo 
Ellison made a brief cameo appearance in the 2010 movie Iron Man 2.

###  Restaurant 
In July 2013, Ellison opened a restaurant in Malibu named Nikita, which closed in December 2014.

###  Farming 
In 2017, Ellison funded a farming company called Sensei Ag with a promise to use AI, robotics, and software to remake the way food was produced. A Wall Street Journal report in February 2025 criticized the effort, saying the endeavor was not keeping its promise due to basic mistakes in technology, leadership, and access to know-how.

###  Tennis 
In 2009, Ellison purchased the Indian Wells Tennis Garden tennis facility in California's Coachella Valley and the Indian Wells Masters tournament for $100 million, and he has invested another $100 million in the club.
In 2010, Ellison purchased a 50% share of the BNP Paribas Open tennis tournament.

###  Yachting 
With the economic downturn of 2010, Ellison sold his share of Rising Sun, the 12th largest yacht in the world, making David Geffen the sole owner. The vessel is 453 feet (138 metres) long, and reportedly cost over $200 million to build. He downsized to Musashi, a 288-foot (88-metre) yacht built by Feadship.

####  Racing 
Ellison competes in yachting through Oracle Team USA. Following success racing Maxi yachts, Ellison founded BMW Oracle Racing to compete for the 2003 Louis Vuitton Cup.
In 2002, Ellison's Oracle's team introduced kite yachting into the America's Cup environment. Kite sail flying lasting about thirty minutes was achieved during testing in New Zealand.
BMW Oracle Racing was the "Challenger of Record" on behalf of the Golden Gate Yacht Club of San Francisco for the 2007 America's Cup in Valencia, Spain, until eliminated from the 2007 Louis Vuitton Cup challenger-selection series in the semi-finals. On February 14, 2010, Ellison's yacht USA 17 won the second race (in the best of three "deed of gift" series) of the 33rd America's Cup, after winning the first race two days earlier. Securing a historic victory, Ellison and his BMW Oracle team became the first challengers to win a "deed of gift" match. The Cup returned to American shores for the first time since 1995. Ellison served as a crew member in the second race. Previously, Ellison had filed several legal challenges, through the Golden Gate Yacht Club, against the way that Ernesto Bertarelli (also one of the world's richest men) proposed to organize the 33rd America's Cup following the 2007 victory of Bertarelli's team Alinghi. The races were finally held in February 2010 in Valencia.
On September 25, 2013, Ellison's Oracle Team USA defeated Emirates Team New Zealand to win the 34th America's Cup in San Francisco Bay, California. Oracle Team USA had been penalized two points in the final for cheating by some team members during the America's Cup World Series warm-up events. The Oracle team came from a 1–8 deficit to win 9–8, in what has been called "one of the greatest comebacks in sports history".
In 2019, Ellison, in conjunction with Russell Coutts, started the SailGP international racing series. The series used F50 foiling catamarans, the fastest class of boat in history with regattas held across the globe. Ellison committed to five years of funding to support the series until it could become self-sustaining. The first season was successful with global audiences of over 1.8 billion.

##  Other endeavors 
In 1992, Ellison shattered his elbow in a high-speed bicycle crash. After receiving treatment at University of California, Davis, Ellison donated $5 million to seed the Lawrence J. Ellison Musculo-Skeletal Research Center. In 1998, the Lawrence J. Ellison Ambulatory Care Center opened on the Sacramento campus of the UC Davis Medical Center.
To settle a 2001 insider trading lawsuit arising from his selling nearly $1 billion of Oracle stock, a court allowed Ellison to donate $100 million to his own charitable foundation without admitting wrongdoing. A California judge refused to allow Oracle to pay Ellison's legal fees of $24 million. Ellison's lawyer had argued that if Ellison were to pay the fees, that could be construed as an admission of guilt. His charitable donations to Stanford University raised questions about the independence of two Stanford professors who evaluated the case's merits for Oracle. 
In 2001, in response to the September 11 attacks, Ellison made a controversial offer to donate software to the federal government that would have enabled it to build and run a national identification database and issue ID cards.
According to Forbes's 2004 list of charitable donations made by the wealthiest 400 Americans, Ellison had donated $151,092,103, about 1% of his estimated personal wealth. In June 2006, he announced he would not honor an earlier pledge of $115 million to Harvard University because of the departure of former president Lawrence Summers. Oracle spokesman Bob Wynne announced, "It was really Larry Summers' brainchild and once it looked like Larry Summers was leaving, Larry Ellison reconsidered".
In 2007, Ellison pledged $500,000 to fortify a community centre in Sderot, Israel, against rocket attacks. In 2014, he donated $10 million to the Friends of the Israel Defense Forces. In 2017, he donated $16.6 million to support the construction of well-being facilities on a new campus for co-ed conscripts.
In August 2010, a report listed Ellison as one of the 40 billionaires who had signed "The Giving Pledge". 
In May 2016, Ellison donated $200 million to the University of Southern California to establish a cancer research center: the Lawrence J. Ellison Institute for Transformative Medicine of USC. It was renamed the Ellison Institute of Technology, and an additional campus was established in Oxford, England, in 2023 with the intention of providing a scholarship program for 20 students each year.
Between 2021 and 2023, Ellison invested $130 million in the Tony Blair Institute for Global Change. Since then he has pledged a further $218 million.

##  Books 
Symonds, Matthew; Ellison, Larry (2004). Softwar: An Intimate Portrait of Larry Ellison and Oracle. New York: Simon & Schuster. ISBN 978-0-7432-2505-2. OCLC 52638805.

##  Recognition 
In 1997, Ellison received the Golden Plate Award of the American Academy of Achievement.
In 2013, Ellison was inducted into the Bay Area Business Hall of Fame.
Ellison was named one of the 100 most influential people in the world by Time magazine in 2024.

##  See also 
Ellison Medical Foundation

##  References 
###  Explanatory notes 
###  Works cited 
Symonds, Matthew; Ellison, Larry (2004). Softwar: An Intimate Portrait of Larry Ellison and Oracle. New York: Simon & Schuster. ISBN 978-0-7432-2505-2. OCLC 52638805.

##  Further reading 
Filion, Avra Amar (2014). The Ellison Effect. Melbourne, FL: Motivational Press. ISBN 9781518380655. OCLC 1054829496.
Leibovich, Mark (2002). The New Imperialists: How Five Restless Kids Grew up to Virtually Rule Your World. Paramus, N.J.: Prentice Hall Press. ISBN 0735203172. OCLC 47990010.
Stone, Florence M. (2002). The Oracle of Oracle: The Story of Volatile CEO Larry Ellison and the Strategies Behind His Company's Phenomenal Success (1st ed.). AMACOM. ISBN 978-0-8144-0639-7. OCLC 503229870.
Wilson, Mike (1998) [1997]. The Difference Between God and Larry Ellison - God Doesn't Think He's Larry Ellison: Inside Oracle Corporation. New York, NY: Quill - William Morrow. ISBN 9780688163532. OCLC 53384755.

##  External links 
Profile at Oracle Corporation
Profile at Forbes
Profile at Bloomberg L.P.
Biography at BBC News
Appearances on C-SPAN
Larry Ellison   on Charlie Rose
Larry Ellison at IMDb
Larry Ellison collected news and commentary at The New York Times
Works by Larry Ellison at Open Library
