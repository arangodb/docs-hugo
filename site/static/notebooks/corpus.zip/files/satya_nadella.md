# Satya Nadella

> *Source: Wikipedia — <https://en.wikipedia.org/wiki/Satya_Nadella>*

Satya Narayana Nadella (born 19 August 1967) is an Indian-American business executive. He is the chairman and chief executive officer (CEO) of Microsoft, succeeding Steve Ballmer in 2014 as CEO and John W. Thompson in 2021 as chairman. Before becoming CEO, he was the executive vice president of Microsoft's cloud and enterprise group, responsible for building and running the company's computing platforms.

##  Early life 
Satya Narayana Nadella was born on 19 August 1967 in a Telugu Hindu family in Hyderabad. His father, Bukkapuram Nadella Yugandhar, was an Indian Administrative Service officer of the 1962 batch. His mother Prabhavati was a Sanskrit lecturer. Yugandhar hailed from Bukkapuram in Anantapur district of Andhra Pradesh; his own father had migrated to Bukkapuram from Nadella village in Guntur district (present-day Palnadu district) of Andhra Pradesh. 
Nadella attended the Hyderabad Public School, Begumpet before receiving a bachelor's degree in electrical engineering from the Manipal Institute of Technology, Mangalore University in Karnataka in 1988. He then traveled to the United States to study for an MS in computer science at the University of Wisconsin–Milwaukee, receiving his degree in 1990. He received an MBA from the University of Chicago Booth School of Business in 1997.

##  Career 
###  Sun Microsystems 
Nadella worked at Sun Microsystems as a member of its technology staff before joining Microsoft in 1992.

###  Microsoft 
####  1992–2014 
At Microsoft, Nadella has led major projects that included the company's move to cloud computing and the development of one of the largest cloud infrastructures in the world.
Nadella worked as the senior vice-president of research and development (R&D) for the Online Services Division and vice-president of the Microsoft Business Division. Later, he was made the president of Microsoft's $19 billion Server and Tools Business and led a transformation of the company's business and technology culture from client services to cloud infrastructure and services. He has been credited for helping bring Microsoft's database, Windows Server and developer tools to its Azure cloud. The revenue from Cloud Services grew to $20.3 billion in June 2013 from $16.6 billion when he took over in 2011. He received $84.5 million in 2016 pay.
In 2013, Nadella's base salary was reportedly $669,167. Including stock bonuses, the total compensation stood at around $7.6 million.
Previous positions held by Nadella include:

President of the Server & Tools Division (9 February 2011 – February 2014)
Senior Vice-president of Research and Development for the Online Services Division (March 2007 – February 2011)
Vice-president of the Business Division
Corporate Vice-president of Business Solutions and Search & Advertising Platform Group
Executive Vice-president of Cloud and Enterprise group

####  Chief executive officer (2014–present) 
On 4 February 2014, Nadella was announced as the new CEO of Microsoft, the third CEO in the company's history, following Bill Gates and Steve Ballmer.
In October 2014, Nadella attended an event on Women in Computing and courted controversy after he made a statement that women should not ask for a raise and should trust the system. Nadella was criticised for the statement and he later apologized on Twitter. He then sent an email to Microsoft employees admitting he was "Completely wrong."

Nadella's tenure at Microsoft has emphasized working with companies and technologies with which Microsoft also competes, including Apple Inc., Salesforce, IBM, and Dropbox. In contrast to previous Microsoft campaigns against the Linux operating system, Nadella proclaimed that "Microsoft ❤️ Linux", and Microsoft joined the Linux Foundation as a Platinum member in 2016.
Under Nadella, Microsoft revised its mission statement to "empower every person and every organization on the planet to achieve more". He orchestrated a cultural shift at Microsoft by emphasizing empathy, collaboration, and 'growth mindset'. He has transformed Microsoft's corporate culture into one that emphasizes continual learning and growth.
In 2014, Nadella's first acquisition with Microsoft was of Mojang, a Swedish game company best known for the computer game Minecraft, for $2.5 billion. He followed that by purchasing Xamarin for an undisclosed amount. He oversaw the purchase of professional network LinkedIn in 2016 for $26.2 billion. On 26 October 2018, Microsoft acquired GitHub for US$7.5 billion.
As of November 2023, Microsoft stock had increased nearly tenfold since Nadella became CEO in 2014, with a 27% annual growth rate, ending a 14-year period of near zero growth.
In 2024, Nadella's compensation from Microsoft totaled $79.1 million, an increase of 63% over his 2023 compensation of $48.5 million.
In January 2026, Nadella demanded that people stop calling artificial intelligence "slop" and instead accept AI as the "new equilibrium" of human nature. The public reaction instead made people double down on the backlash, and the term "Microslop" became popular on social media, leading to it being labeled as a Streisand effect.

####  Sports 
Nadella, Soma Somasegar, Samir Bodas, Ashok Krishnamurthi, Sanjay Parthasarathy, and the GMR Group purchased the Seattle Orcas cricket team which is a part of 2023 Major League Cricket season.

###  Boards and committees 
Board of Directors, Starbucks (2017–2024)
Board of Trustees, Fred Hutchinson Cancer Center
Board of Trustees, University of Chicago
Chairman, The Business Council (2021 to 2022)

##  Awards and recognition 
In 2018 and 2024, Nadella was a Time 100 honoree. In 2019, he was named Financial Times Person of the Year and Fortune Magazine Businessperson of the Year. In 2014, Nadella was awarded the CNN-News18 Indian of the Year and in 2020, was recognized as Global Indian Business Icon at CNBC-TV18's India Business Leader Awards. In 2015, the Government of India awarded Nadella the Pravasi Bharatiya Samman (awarded to Overseas Indians) and in 2022 the Padma Bhushan, the third highest civilian award in India.
Nadella was awarded an honorary PhD from the Georgia Institute of Technology in January 2024.

##  Personal life 
In 1992, Nadella married Anupama Priyadarshini, the daughter of his father's Indian Administrative Service (IAS) batchmate. Both Nadella and Anupama are the only children from their parents. She was his junior at Manipal pursuing a B.Arch in the Faculty of Architecture. The couple have three children, a son (deceased) and two daughters, and live in Clyde Hill and Bellevue, Washington. His son Zain was a legally blind quadriplegic with cerebral palsy. Zain died in February 2022, at the age of 26. According to Nadella, being the father of a child with special needs was a turning point in his life. 
Nadella is an avid reader of American and Indian poetry and enjoys cricket, having played on his school team. He credits cricket for improving his leadership skills. 
Nadella and his wife Anupama are part of the ownership group of Seattle Sounders FC, a Major League Soccer club.
In 2017, Nadella published a book titled Hit Refresh, exploring his life and career at Microsoft. He announced that the profits from the book would go to Microsoft Philanthropies and through that to nonprofit organizations.

##  Publications 
Hit Refresh: The Quest to Rediscover Microsoft's Soul and Imagine a Better Future for Everyone (2017). ISBN 978-0-06-265250-8 (audiobook ISBN 978-0-06-269480-5)

##  Notes 
##  References 
##  External links 
Appearances on C-SPAN
Profile from Microsoft
Profile on Forbes
